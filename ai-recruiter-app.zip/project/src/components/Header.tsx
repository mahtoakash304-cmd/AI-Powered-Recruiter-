import React from 'react';
import { 
  Briefcase, 
  Sparkles, 
  RotateCcw, 
  Download, 
  FileText, 
  Users, 
  CheckCircle2, 
  Sliders
} from 'lucide-react';
import { RankingReport } from '../types';

interface HeaderProps {
  activeTab: 'job' | 'resumes' | 'leaderboard' | 'matrix' | 'briefing';
  setActiveTab: (tab: 'job' | 'resumes' | 'leaderboard' | 'matrix' | 'briefing') => void;
  report: RankingReport | null;
  onLoadBenchmark: () => void;
  onReset: () => void;
  onOpenExport: () => void;
  isEvaluating: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  report,
  onLoadBenchmark,
  onReset,
  onOpenExport,
  isEvaluating
}) => {
  const candidateCount = report?.candidates.length || 0;
  const tier1Count = report?.statistics.tierCounts.tier1 || 0;

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Identity */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-200">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-slate-900 text-lg tracking-tight font-['Space_Grotesk']">
                  AI Recruiter
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  <Sparkles className="w-3 h-3 mr-1 text-indigo-600" />
                  Gemini 3.7
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                Multi-Dimensional Candidate Ranking & Assessment Engine
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center space-x-1 sm:space-x-2 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs sm:text-sm font-medium">
            <button
              id="tab-job-spec"
              onClick={() => setActiveTab('job')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center space-x-1.5 ${
                activeTab === 'job'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>1. Job & Rubric</span>
            </button>

            <button
              id="tab-resumes-ingestion"
              onClick={() => setActiveTab('resumes')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center space-x-1.5 ${
                activeTab === 'resumes'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>2. Ingest Resumes</span>
            </button>

            <button
              id="tab-rankings-leaderboard"
              onClick={() => setActiveTab('leaderboard')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center space-x-1.5 ${
                activeTab === 'leaderboard'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>3. Leaderboard</span>
              {candidateCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-indigo-100 text-indigo-800 font-bold">
                  {candidateCount}
                </span>
              )}
            </button>

            <button
              id="tab-matrix-view"
              onClick={() => setActiveTab('matrix')}
              className={`hidden md:flex px-3 py-1.5 rounded-lg transition-all items-center space-x-1.5 ${
                activeTab === 'matrix'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <span>Matrix</span>
            </button>

            <button
              id="tab-briefing-view"
              onClick={() => setActiveTab('briefing')}
              className={`hidden md:flex px-3 py-1.5 rounded-lg transition-all items-center space-x-1.5 ${
                activeTab === 'briefing'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <span>Executive Briefing</span>
            </button>
          </nav>

          {/* Quick Action Buttons */}
          <div className="flex items-center space-x-2">
            <button
              id="btn-load-benchmark-demo"
              onClick={onLoadBenchmark}
              disabled={isEvaluating}
              className="inline-flex items-center px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 transition-colors shadow-2xs disabled:opacity-50"
              title="Load full Senior AI Engineer benchmark dataset with 5 realistic candidates"
            >
              <Sparkles className="w-3.5 h-3.5 mr-1 text-indigo-600" />
              <span className="hidden sm:inline">Benchmark Demo</span>
              <span className="sm:hidden">Demo</span>
            </button>

            {candidateCount > 0 && (
              <button
                id="btn-open-export-modal"
                onClick={onOpenExport}
                className="inline-flex items-center px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <Download className="w-3.5 h-3.5 mr-1 text-slate-600" />
                <span className="hidden sm:inline">Export</span>
              </button>
            )}

            <button
              id="btn-reset-workspace"
              onClick={onReset}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              title="Reset workspace"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
