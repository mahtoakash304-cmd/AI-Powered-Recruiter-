import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  HelpCircle, 
  Mail, 
  FileText, 
  Copy, 
  Check, 
  ShieldAlert, 
  Award, 
  Sparkles, 
  UserCheck, 
  ExternalLink,
  ChevronRight,
  Send
} from 'lucide-react';
import { CandidateEvaluation, MustHaveCheck, DimensionScore } from '../types';

interface CandidateDossierModalProps {
  candidate: CandidateEvaluation | null;
  onClose: () => void;
  onOpenInterviewKit: (candidate: CandidateEvaluation) => void;
}

export const CandidateDossierModal: React.FC<CandidateDossierModalProps> = ({
  candidate,
  onClose,
  onOpenInterviewKit
}) => {
  const [activeTab, setActiveTab] = useState<'scorecard' | 'musthaves' | 'interview' | 'comms' | 'resume'>('scorecard');
  const [copiedType, setCopiedType] = useState<string | null>(null);

  if (!candidate) return null;

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const getMustHaveStatusIcon = (status: MustHaveCheck['status']) => {
    switch (status) {
      case 'MET':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />;
      case 'PARTIAL':
        return <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />;
      case 'NOT_MET':
        return <XCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Header Profile Banner */}
        <div className="p-5 bg-slate-900 text-white flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800">
          <div className="flex items-start space-x-3.5">
            <div className="w-11 h-11 rounded-lg bg-blue-600 flex items-center justify-center text-white font-extrabold text-base shadow-xs shrink-0">
              {candidate.name.split(' ').map((n) => n[0]).join('')}
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">{candidate.name}</h2>
                <span className="px-2 py-0.5 rounded text-[11px] font-extrabold bg-slate-800 text-blue-400 border border-slate-700 uppercase tracking-wider">
                  {candidate.tier.replace(/_/g, ' ')}
                </span>
                <span className={`px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider ${
                  candidate.recommendationVerdict === 'Strong Hire'
                    ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                    : candidate.recommendationVerdict === 'Hire'
                    ? 'bg-teal-950/80 text-teal-400 border border-teal-800'
                    : candidate.recommendationVerdict === 'Leaning Hire'
                    ? 'bg-amber-950/80 text-amber-400 border border-amber-800'
                    : 'bg-rose-950/80 text-rose-400 border border-rose-800'
                }`}>
                  {candidate.recommendationVerdict}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400 mt-1">
                <span className="font-semibold text-slate-200">{candidate.currentRole}</span>
                {candidate.currentCompany && <span>@ {candidate.currentCompany}</span>}
                <span>•</span>
                <span>{candidate.totalExperienceYears} YOE</span>
                <span>•</span>
                <span className="font-mono text-slate-300">{candidate.email}</span>
                {candidate.phone && (
                  <>
                    <span>•</span>
                    <span>{candidate.phone}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Right Side: Score Card & Close */}
          <div className="flex items-center space-x-4 self-end md:self-center">
            <div className="text-right">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Match Score</span>
              <div className="text-xl font-bold font-mono text-emerald-400">
                {candidate.matchScore.toFixed(1)}%
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex items-center space-x-1 px-5 border-b border-slate-200 bg-slate-50 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('scorecard')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'scorecard'
                ? 'border-blue-600 text-blue-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Scorecard & Evidence</span>
          </button>

          <button
            onClick={() => setActiveTab('musthaves')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'musthaves'
                ? 'border-blue-600 text-blue-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Must-Have Verification</span>
          </button>

          <button
            onClick={() => setActiveTab('interview')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'interview'
                ? 'border-blue-600 text-blue-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Interview Probe Kit ({candidate.interviewKit?.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('comms')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'comms'
                ? 'border-blue-600 text-blue-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Mail className="w-4 h-4" />
            <span>Outreach & Notices</span>
          </button>

          <button
            onClick={() => setActiveTab('resume')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center space-x-1.5 whitespace-nowrap ${
              activeTab === 'resume'
                ? 'border-blue-600 text-blue-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Raw Resume</span>
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: SCORECARD & EVIDENCE */}
          {activeTab === 'scorecard' && (
            <div className="space-y-6">
              {/* Executive Summary */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-xs font-bold text-slate-900 uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  <span>Executive Recruiter Evaluation</span>
                </div>
                <p className="text-sm font-semibold text-slate-900">
                  {candidate.keyVerdictHeadline}
                </p>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {candidate.executiveSummary}
                </p>
              </div>

              {/* 5-Pillar Breakdown Cards */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">5-Pillar Rubric Breakdown & Evidence</h3>

                {Object.entries(candidate.dimensions || {}).map(([dimKey, dim]: [string, any]) => {
                  const labels: Record<string, string> = {
                    technicalSkills: 'Technical & Architectural Depth',
                    experienceSeniority: 'Experience & Seniority Level',
                    domainIndustryFit: 'Domain & Industry Fit',
                    softSkillsLeadership: 'Leadership & Soft Skills',
                    educationCertifications: 'Education & Credentials'
                  };

                  return (
                    <div 
                      key={dimKey}
                      className="p-4 rounded-xl border border-slate-200 bg-white space-y-2.5 shadow-2xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-slate-900">
                          {labels[dimKey] || dimKey}
                        </span>
                        <div className="flex items-center space-x-2">
                          <span className="text-[11px] text-slate-500">
                            Weight: {Math.round(dim.weight * 100)}%
                          </span>
                          <span className="font-mono font-bold text-xs text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                            {dim.score.toFixed(1)} / 100
                          </span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 leading-relaxed">
                        {dim.rationale}
                      </p>

                      {dim.evidenceFound?.length > 0 && (
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">
                            Verified Evidence Found:
                          </span>
                          <div className="flex flex-wrap gap-1">
                            {dim.evidenceFound.map((ev: string, i: number) => (
                              <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                                ✓ {ev}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {dim.missingOrWeak?.length > 0 && dim.missingOrWeak[0] !== 'None observed' && (
                        <div className="space-y-1 pt-1">
                          <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider">
                            Missing / Weak Areas:
                          </span>
                          <div className="flex flex-wrap gap-1">
                            {dim.missingOrWeak.map((mw: string, i: number) => (
                              <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                                ⚠ {mw}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Strengths & Gaps 2-column grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Key Strengths */}
                <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-200 space-y-2">
                  <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider flex items-center">
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                    Key Strengths & Differentiators
                  </h4>
                  <ul className="space-y-1.5 text-xs text-emerald-950">
                    {candidate.keyStrengths?.map((s, i) => (
                      <li key={i} className="flex items-start space-x-1.5">
                        <span className="text-emerald-600 font-bold">•</span>
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Critical Gaps & Risks */}
                <div className="p-4 rounded-xl bg-amber-50/50 border border-amber-200 space-y-2">
                  <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center">
                    <ShieldAlert className="w-3.5 h-3.5 mr-1.5 text-amber-600" />
                    Critical Gaps & Red Flags
                  </h4>
                  <ul className="space-y-1.5 text-xs text-amber-950">
                    {candidate.criticalGaps?.map((g, i) => (
                      <li key={i} className="flex items-start space-x-1.5">
                        <span className="text-amber-600 font-bold">•</span>
                        <span>{g}</span>
                      </li>
                    ))}
                    {candidate.riskFactors?.map((r, i) => (
                      <li key={`risk-${i}`} className="flex items-start space-x-1.5 text-rose-900">
                        <span className="text-rose-600 font-bold">• Risk:</span>
                        <span>{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: MUST-HAVE VERIFICATION */}
          {activeTab === 'musthaves' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Must-Have Non-Negotiable Requirements Verification
                </h3>
                <span className="text-xs text-slate-500 font-medium">
                  Verifiable proof audit from resume text
                </span>
              </div>

              <div className="space-y-3">
                {candidate.mustHaveChecks?.map((check, idx) => (
                  <div 
                    key={idx}
                    className="p-4 rounded-xl border border-slate-200 bg-white space-y-2 shadow-2xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start space-x-2">
                        {getMustHaveStatusIcon(check.status)}
                        <span className="text-xs font-bold text-slate-900">{check.requirement}</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        check.status === 'MET'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : check.status === 'PARTIAL'
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-rose-50 text-rose-800 border border-rose-200'
                      }`}>
                        {check.status}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 italic">
                      "{check.evidence || 'No direct evidence identified in resume text.'}"
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: TAILORED INTERVIEW KIT */}
          {activeTab === 'interview' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Candidate-Specific Interview Probe Questions
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Tailored probes to test candidate claims, real-world depth, and address critical gaps.
                  </p>
                </div>
                <button
                  onClick={() => onOpenInterviewKit(candidate)}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-xs flex items-center space-x-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Launch Live Interview Screen</span>
                </button>
              </div>

              <div className="space-y-4">
                {candidate.interviewKit?.map((probe, idx) => (
                  <div 
                    key={probe.id || idx}
                    className="p-4 rounded-xl border border-slate-200 bg-white space-y-3 shadow-2xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                          {probe.category}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                          {probe.difficulty}
                        </span>
                      </div>
                      <span className="text-xs font-mono text-slate-400">Probe #{idx + 1}</span>
                    </div>

                    <p className="text-xs font-bold text-slate-900 leading-relaxed">
                      "{probe.question}"
                    </p>

                    <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600">
                      <strong>Intent:</strong> {probe.intent}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1 text-xs">
                      {/* Positive signals */}
                      <div className="space-y-1">
                        <span className="font-bold text-emerald-700 text-[11px] uppercase tracking-wider">
                          ✓ Positive Signals to Listen For:
                        </span>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          {probe.positiveSignals?.map((sig, sIdx) => (
                            <li key={sIdx} className="flex items-start space-x-1">
                              <span className="text-emerald-600 font-bold">•</span>
                              <span>{sig}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Red Flags */}
                      <div className="space-y-1">
                        <span className="font-bold text-rose-700 text-[11px] uppercase tracking-wider">
                          ⚠ Red Flag Signals to Watch For:
                        </span>
                        <ul className="space-y-1 text-slate-700 text-[11px]">
                          {probe.redFlagSignals?.map((red, rIdx) => (
                            <li key={rIdx} className="flex items-start space-x-1">
                              <span className="text-rose-600 font-bold">•</span>
                              <span>{red}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: COMMUNICATIONS */}
          {activeTab === 'comms' && (
            <div className="space-y-6">
              {/* Outreach Email */}
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center">
                    <Send className="w-3.5 h-3.5 mr-1.5 text-blue-600" />
                    Personalized Outreach Email
                  </h4>
                  <button
                    onClick={() => copyToClipboard(
                      `Subject: ${candidate.communications?.outreachEmail?.subject}\n\n${candidate.communications?.outreachEmail?.body}`,
                      'outreach'
                    )}
                    className="px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors flex items-center space-x-1"
                  >
                    {copiedType === 'outreach' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedType === 'outreach' ? 'Copied' : 'Copy Email'}</span>
                  </button>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="p-2 bg-slate-50 rounded-lg border border-slate-200 font-mono text-slate-800">
                    <strong>Subject:</strong> {candidate.communications?.outreachEmail?.subject}
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 font-sans text-slate-800 whitespace-pre-wrap leading-relaxed">
                    {candidate.communications?.outreachEmail?.body}
                  </div>
                </div>
              </div>

              {/* Rejection Email */}
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center text-rose-900">
                    <Mail className="w-3.5 h-3.5 mr-1.5 text-rose-600" />
                    Constructive Rejection Email
                  </h4>
                  <button
                    onClick={() => copyToClipboard(
                      `Subject: ${candidate.communications?.rejectionEmail?.subject}\n\n${candidate.communications?.rejectionEmail?.body}`,
                      'rejection'
                    )}
                    className="px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors flex items-center space-x-1"
                  >
                    {copiedType === 'rejection' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedType === 'rejection' ? 'Copied' : 'Copy Letter'}</span>
                  </button>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="p-2 bg-slate-50 rounded-lg border border-slate-200 font-mono text-slate-800">
                    <strong>Subject:</strong> {candidate.communications?.rejectionEmail?.subject}
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 font-sans text-slate-800 whitespace-pre-wrap leading-relaxed">
                    {candidate.communications?.rejectionEmail?.body}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: RAW RESUME */}
          {activeTab === 'resume' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Original Resume Transcript</h3>
                <button
                  onClick={() => copyToClipboard(candidate.rawResumeText, 'rawResume')}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 flex items-center space-x-1"
                >
                  {copiedType === 'rawResume' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>Copy Resume Text</span>
                </button>
              </div>
              <div className="p-4 rounded-xl bg-slate-900 text-slate-200 font-mono text-xs whitespace-pre-wrap max-h-[500px] overflow-y-auto leading-relaxed border border-slate-800">
                {candidate.rawResumeText}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Evaluated on {new Date(candidate.evaluatedAt).toLocaleDateString()} with Gemini 3.7
          </span>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => onOpenInterviewKit(candidate)}
              className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 transition-colors flex items-center space-x-1.5"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Launch Live Interview Screen</span>
            </button>
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 transition-colors"
            >
              Close Dossier
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
