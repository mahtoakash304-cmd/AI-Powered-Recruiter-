import React, { useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';
import { 
  Trophy, 
  Layers, 
  Sliders, 
  CheckCircle, 
  ArrowRight,
  Sparkles,
  BarChart2,
  Table as TableIcon
} from 'lucide-react';
import { RankingReport, CandidateEvaluation } from '../types';

interface CompetencyMatrixProps {
  report: RankingReport;
  onSelectCandidate: (candidate: CandidateEvaluation) => void;
}

export const CompetencyMatrix: React.FC<CompetencyMatrixProps> = ({
  report,
  onSelectCandidate
}) => {
  const [viewMode, setViewMode] = useState<'chart' | 'table'>('table');

  const candidates = report.candidates;
  const weights = report.jobProfile.scoringWeights;

  // Prepare chart dataset
  const chartData = candidates.map((c) => ({
    name: c.name.split(' ')[0],
    fullName: c.name,
    Technical: c.dimensions?.technicalSkills?.score || 0,
    Experience: c.dimensions?.experienceSeniority?.score || 0,
    DomainFit: c.dimensions?.domainIndustryFit?.score || 0,
    Leadership: c.dimensions?.softSkillsLeadership?.score || 0,
    Education: c.dimensions?.educationCertifications?.score || 0,
    OverallMatch: c.matchScore,
  }));

  // Identify highest score in each dimension for highlighting
  const topScores = {
    technical: Math.max(...candidates.map((c) => c.dimensions?.technicalSkills?.score || 0)),
    experience: Math.max(...candidates.map((c) => c.dimensions?.experienceSeniority?.score || 0)),
    domain: Math.max(...candidates.map((c) => c.dimensions?.domainIndustryFit?.score || 0)),
    leadership: Math.max(...candidates.map((c) => c.dimensions?.softSkillsLeadership?.score || 0)),
    education: Math.max(...candidates.map((c) => c.dimensions?.educationCertifications?.score || 0)),
    overall: Math.max(...candidates.map((c) => c.matchScore || 0))
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & View Toggle */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center">
            <Layers className="w-5 h-5 mr-2 text-blue-600" />
            Side-by-Side Competency Comparison Matrix
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Comparative analysis of all candidates evaluated against the 5-pillar weighting rubric for <strong className="text-slate-800">{report.jobProfile.title}</strong>.
          </p>
        </div>

        <div className="flex items-center space-x-1.5 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-semibold">
          <button
            onClick={() => setViewMode('table')}
            className={`px-3 py-1.5 rounded-md flex items-center space-x-1.5 transition-all ${
              viewMode === 'table' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TableIcon className="w-3.5 h-3.5" />
            <span>Table View</span>
          </button>
          <button
            onClick={() => setViewMode('chart')}
            className={`px-3 py-1.5 rounded-md flex items-center space-x-1.5 transition-all ${
              viewMode === 'chart' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Visual Charts</span>
          </button>
        </div>
      </div>

      {/* View: Table Mode */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  <th className="py-3 px-4">Rank & Candidate</th>
                  <th className="py-3 px-3 text-center">
                    Technical ({Math.round(weights.technicalSkills * 100)}%)
                  </th>
                  <th className="py-3 px-3 text-center">
                    Experience ({Math.round(weights.experienceSeniority * 100)}%)
                  </th>
                  <th className="py-3 px-3 text-center">
                    Domain Fit ({Math.round(weights.domainIndustryFit * 100)}%)
                  </th>
                  <th className="py-3 px-3 text-center">
                    Leadership ({Math.round(weights.softSkillsLeadership * 100)}%)
                  </th>
                  <th className="py-3 px-3 text-center">
                    Education ({Math.round(weights.educationCertifications * 100)}%)
                  </th>
                  <th className="py-3 px-4 text-center">Overall Match</th>
                  <th className="py-3 px-4 text-center">Verdict</th>
                  <th className="py-3 px-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {candidates.map((candidate, idx) => {
                  const techScore = candidate.dimensions?.technicalSkills?.score || 0;
                  const expScore = candidate.dimensions?.experienceSeniority?.score || 0;
                  const domainScore = candidate.dimensions?.domainIndustryFit?.score || 0;
                  const leadScore = candidate.dimensions?.softSkillsLeadership?.score || 0;
                  const eduScore = candidate.dimensions?.educationCertifications?.score || 0;

                  return (
                    <tr 
                      key={candidate.id}
                      className="hover:bg-slate-50/70 transition-colors group cursor-pointer"
                      onClick={() => onSelectCandidate(candidate)}
                    >
                      {/* Name & Title */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-3">
                          <span className={`w-5 h-5 rounded text-[11px] font-bold flex items-center justify-center ${
                            idx === 0
                              ? 'bg-amber-100 text-amber-900 border border-amber-300'
                              : 'bg-slate-100 text-slate-700'
                          }`}>
                            #{idx + 1}
                          </span>
                          <div>
                            <span className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors block text-xs">
                              {candidate.name}
                            </span>
                            <span className="text-[11px] text-slate-500">{candidate.currentRole}</span>
                          </div>
                        </div>
                      </td>

                      {/* Technical Score */}
                      <td className="py-3.5 px-3 text-center">
                        <div className="inline-flex items-center flex-col">
                          <span className={`font-mono font-bold text-xs ${
                            techScore === topScores.technical ? 'text-amber-600 font-extrabold' : 'text-slate-800'
                          }`}>
                            {techScore.toFixed(1)}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {candidate.dimensions?.technicalSkills?.weightedScore.toFixed(1)} pts
                          </span>
                        </div>
                      </td>

                      {/* Experience Score */}
                      <td className="py-3.5 px-3 text-center">
                        <div className="inline-flex items-center flex-col">
                          <span className={`font-mono font-bold text-xs ${
                            expScore === topScores.experience ? 'text-sky-600 font-extrabold' : 'text-slate-800'
                          }`}>
                            {expScore.toFixed(1)}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {candidate.dimensions?.experienceSeniority?.weightedScore.toFixed(1)} pts
                          </span>
                        </div>
                      </td>

                      {/* Domain Fit Score */}
                      <td className="py-3.5 px-3 text-center">
                        <div className="inline-flex items-center flex-col">
                          <span className={`font-mono font-bold text-xs ${
                            domainScore === topScores.domain ? 'text-emerald-600 font-extrabold' : 'text-slate-800'
                          }`}>
                            {domainScore.toFixed(1)}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {candidate.dimensions?.domainIndustryFit?.weightedScore.toFixed(1)} pts
                          </span>
                        </div>
                      </td>

                      {/* Leadership Score */}
                      <td className="py-3.5 px-3 text-center">
                        <div className="inline-flex items-center flex-col">
                          <span className={`font-mono font-bold text-xs ${
                            leadScore === topScores.leadership ? 'text-purple-600 font-extrabold' : 'text-slate-800'
                          }`}>
                            {leadScore.toFixed(1)}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {candidate.dimensions?.softSkillsLeadership?.weightedScore.toFixed(1)} pts
                          </span>
                        </div>
                      </td>

                      {/* Education Score */}
                      <td className="py-3.5 px-3 text-center">
                        <div className="inline-flex items-center flex-col">
                          <span className={`font-mono font-bold text-xs ${
                            eduScore === topScores.education ? 'text-pink-600 font-extrabold' : 'text-slate-800'
                          }`}>
                            {eduScore.toFixed(1)}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {candidate.dimensions?.educationCertifications?.weightedScore.toFixed(1)} pts
                          </span>
                        </div>
                      </td>

                      {/* Overall Match */}
                      <td className="py-3.5 px-4 text-center">
                        <span className={`font-mono font-bold text-xs px-2 py-0.5 rounded ${
                          candidate.matchScore >= 88
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : candidate.matchScore >= 75
                            ? 'bg-blue-50 text-blue-800 border border-blue-200'
                            : candidate.matchScore >= 60
                            ? 'bg-amber-50 text-amber-800 border border-amber-200'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {candidate.matchScore.toFixed(1)}%
                        </span>
                      </td>

                      {/* Verdict */}
                      <td className="py-3.5 px-4 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider ${
                          candidate.recommendationVerdict === 'Strong Hire'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : candidate.recommendationVerdict === 'Hire'
                            ? 'bg-teal-50 text-teal-700 border border-teal-200'
                            : candidate.recommendationVerdict === 'Leaning Hire'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}>
                          {candidate.recommendationVerdict}
                        </span>
                      </td>

                      <td className="py-3.5 px-3 text-right">
                        <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* View: Visual Chart Comparison */
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-6">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Multi-Dimensional Competency Breakdown by Candidate
          </h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="fullName" tick={{ fontSize: 11 }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px 0 rgb(0 0 0 / 0.05)', fontSize: '11px' }} 
                />
                <Legend wrapperStyle={{ fontSize: 11, paddingTop: 10 }} />
                <Bar dataKey="Technical" fill="#2563eb" radius={[3, 3, 0, 0]} name="Technical Depth" />
                <Bar dataKey="Experience" fill="#0284c7" radius={[3, 3, 0, 0]} name="Experience / Tenure" />
                <Bar dataKey="DomainFit" fill="#10b981" radius={[3, 3, 0, 0]} name="Domain Fit" />
                <Bar dataKey="Leadership" fill="#8b5cf6" radius={[3, 3, 0, 0]} name="Leadership" />
                <Bar dataKey="Education" fill="#ec4899" radius={[3, 3, 0, 0]} name="Education" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
};
