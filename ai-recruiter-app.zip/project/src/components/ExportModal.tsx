import React, { useState } from 'react';
import { 
  Download, 
  X, 
  FileText, 
  Code2, 
  Check, 
  Copy, 
  Printer, 
  Table as TableIcon 
} from 'lucide-react';
import { RankingReport } from '../types';

interface ExportModalProps {
  report: RankingReport | null;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  report,
  onClose
}) => {
  const [copiedType, setCopiedType] = useState<string | null>(null);

  if (!report) return null;

  // Generate Markdown report string
  const generateMarkdownReport = () => {
    const lines = [
      `# AI Recruiter Candidate Ranking Report`,
      `**Position:** ${report.jobProfile.title} | **Company:** ${report.jobProfile.company}`,
      `**Location:** ${report.jobProfile.location} | **Seniority:** ${report.jobProfile.seniorityLevel}`,
      `**Report Generated:** ${new Date(report.evaluatedAt).toLocaleString()}`,
      '',
      `## Executive Summary & Talent Pool Synthesis`,
      report.executiveBriefing?.topCandidateHighlights || '',
      '',
      `## Candidate Leaderboard & Rankings`,
      `| Rank | Candidate | Match Score | Verdict | Tier | Current Role |`,
      `| --- | --- | --- | --- | --- | --- |`,
      ...report.candidates.map((c, i) => 
        `| #${i + 1} | ${c.name} | ${c.matchScore.toFixed(1)}% | ${c.recommendationVerdict} | ${c.tier} | ${c.currentRole} |`
      ),
      '',
      `## Detailed Candidate Evaluations`,
      ...report.candidates.map((c, i) => `
### #${i + 1} - ${c.name} (${c.matchScore.toFixed(1)}% Match - ${c.recommendationVerdict})
- **Current Role:** ${c.currentRole} (${c.totalExperienceYears} yrs experience)
- **Contact:** ${c.email} | ${c.phone || 'N/A'}
- **Verdict Headline:** ${c.keyVerdictHeadline}
- **Executive Summary:** ${c.executiveSummary}

#### Key Strengths:
${c.keyStrengths?.map((s) => `  - ${s}`).join('\n')}

#### Critical Gaps & Risks:
${c.criticalGaps?.map((g) => `  - ${g}`).join('\n')}
${c.riskFactors?.map((r) => `  - Risk: ${r}`).join('\n')}

#### Must-Have Requirements Audit:
${c.mustHaveChecks?.map((m) => `  - [${m.status === 'MET' ? 'x' : ' '}] **${m.requirement}**: ${m.evidence}`).join('\n')}
      `),
      '',
      `## Strategic Hiring Tradeoffs`,
      report.executiveBriefing?.hiringRisksAndTradeoffs || '',
      '',
      `## Recommended Immediate Next Steps`,
      ...(report.executiveBriefing?.recommendedNextSteps || []).map((s) => `- [ ] ${s}`),
    ];

    return lines.join('\n');
  };

  // Generate CSV string
  const generateCSV = () => {
    const headers = [
      'Rank',
      'Name',
      'Match Score (%)',
      'Verdict',
      'Tier',
      'Current Role',
      'Experience (Years)',
      'Email',
      'Technical Score',
      'Experience Score',
      'Domain Fit Score',
      'Leadership Score',
      'Education Score'
    ];

    const rows = report.candidates.map((c, idx) => [
      `"${idx + 1}"`,
      `"${c.name}"`,
      `"${c.matchScore.toFixed(1)}"`,
      `"${c.recommendationVerdict}"`,
      `"${c.tier}"`,
      `"${c.currentRole}"`,
      `"${c.totalExperienceYears}"`,
      `"${c.email}"`,
      `"${c.dimensions?.technicalSkills?.score.toFixed(1) || 0}"`,
      `"${c.dimensions?.experienceSeniority?.score.toFixed(1) || 0}"`,
      `"${c.dimensions?.domainIndustryFit?.score.toFixed(1) || 0}"`,
      `"${c.dimensions?.softSkillsLeadership?.score.toFixed(1) || 0}"`,
      `"${c.dimensions?.educationCertifications?.score.toFixed(1) || 0}"`
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  };

  const downloadFile = (content: string, fileName: string, contentType: string) => {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-xl w-full flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">Export Candidate Assessment Report</h3>
              <p className="text-[11px] text-slate-500">{report.jobProfile.title} ({report.candidates.length} candidates)</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Options */}
        <div className="p-5 space-y-3">
          {/* Option 1: Markdown Report */}
          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 hover:bg-slate-50 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <FileText className="w-4 h-4 text-blue-600 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-slate-900">Comprehensive Markdown Dossier</h4>
                <p className="text-[11px] text-slate-500">Includes candidate breakdown, scorecards, and next steps.</p>
              </div>
            </div>

            <div className="flex items-center space-x-2 shrink-0">
              <button
                onClick={() => copyToClipboard(generateMarkdownReport(), 'md')}
                className="px-2.5 py-1.5 rounded-md text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 transition-colors"
              >
                {copiedType === 'md' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => downloadFile(generateMarkdownReport(), `${report.jobProfile.title.toLowerCase().replace(/\s+/g, '_')}_ranking_report.md`, 'text/markdown')}
                className="px-3 py-1.5 rounded-md text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-2xs transition-colors"
              >
                Download .MD
              </button>
            </div>
          </div>

          {/* Option 2: CSV Spreadsheet */}
          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 hover:bg-slate-50 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <TableIcon className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-slate-900">Spreadsheet Data (CSV)</h4>
                <p className="text-[11px] text-slate-500">Tabular candidate matrix for Google Sheets or Excel.</p>
              </div>
            </div>

            <button
              onClick={() => downloadFile(generateCSV(), `${report.jobProfile.title.toLowerCase().replace(/\s+/g, '_')}_candidates.csv`, 'text/csv')}
              className="px-3 py-1.5 rounded-md text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-2xs transition-colors shrink-0"
            >
              Download .CSV
            </button>
          </div>

          {/* Option 3: Raw JSON */}
          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/50 hover:bg-slate-50 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Code2 className="w-4 h-4 text-amber-600 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-slate-900">Structured JSON Export</h4>
                <p className="text-[11px] text-slate-500">Complete raw evaluation dataset with all schema fields.</p>
              </div>
            </div>

            <button
              onClick={() => downloadFile(JSON.stringify(report, null, 2), `${report.jobProfile.title.toLowerCase().replace(/\s+/g, '_')}_data.json`, 'application/json')}
              className="px-3 py-1.5 rounded-md text-xs font-bold text-white bg-slate-800 hover:bg-slate-900 shadow-2xs transition-colors shrink-0"
            >
              Download .JSON
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
