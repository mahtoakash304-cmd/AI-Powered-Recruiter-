import React, { useState } from 'react';
import { 
  Sparkles, 
  Layers, 
  Sliders, 
  CheckCircle2, 
  Plus, 
  X, 
  Briefcase, 
  Building, 
  MapPin, 
  Clock, 
  Code2, 
  ArrowRight,
  BookOpen,
  Loader2
} from 'lucide-react';
import { JobProfile, ScoringWeights } from '../types';
import { SAMPLE_JOB_PROFILES } from '../data/sampleData';

interface JobProfileEditorProps {
  jobProfile: JobProfile;
  setJobProfile: (profile: JobProfile) => void;
  onProceedToResumes: () => void;
}

export const JobProfileEditor: React.FC<JobProfileEditorProps> = ({
  jobProfile,
  setJobProfile,
  onProceedToResumes
}) => {
  const [rawJobText, setRawJobText] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [newMustHave, setNewMustHave] = useState<string>('');
  const [newNiceToHave, setNewNiceToHave] = useState<string>('');
  const [newTech, setNewTech] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Handle AI extraction of Job Description
  const handleAnalyzeJobText = async () => {
    if (!rawJobText.trim()) return;
    setIsAnalyzing(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/analyze-job', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobText: rawJobText })
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to analyze job description');
      }

      const analyzedProfile: JobProfile = await response.json();
      setJobProfile(analyzedProfile);
    } catch (err: any) {
      console.error('Job analysis error:', err);
      setErrorMsg(err.message || 'Error communicating with AI service. Please check your API key or try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Select sample job preset
  const handleSelectPreset = (preset: JobProfile) => {
    setJobProfile(preset);
    setRawJobText(preset.summary + '\n\nMust Haves:\n' + preset.mustHaveRequirements.join('\n') + '\n\nNice to Haves:\n' + preset.niceToHaveRequirements.join('\n'));
  };

  // Adjust weights and ensure they stay normalized
  const handleWeightChange = (key: keyof ScoringWeights, value: number) => {
    const rawVal = Math.max(0.01, Math.min(1.0, value / 100));
    const currentWeights = { ...jobProfile.scoringWeights, [key]: rawVal };
    
    // Normalize so all 5 sum to 1.0
    const sum: number = (Object.values(currentWeights) as number[]).reduce((a: number, b: number) => a + Number(b || 0), 0) || 1;
    const normalized: ScoringWeights = {
      technicalSkills: Number(((currentWeights.technicalSkills || 0) / sum).toFixed(2)),
      experienceSeniority: Number(((currentWeights.experienceSeniority || 0) / sum).toFixed(2)),
      domainIndustryFit: Number(((currentWeights.domainIndustryFit || 0) / sum).toFixed(2)),
      softSkillsLeadership: Number(((currentWeights.softSkillsLeadership || 0) / sum).toFixed(2)),
      educationCertifications: Number(((currentWeights.educationCertifications || 0) / sum).toFixed(2)),
    };

    setJobProfile({
      ...jobProfile,
      scoringWeights: normalized
    });
  };

  const addMustHave = () => {
    if (!newMustHave.trim()) return;
    setJobProfile({
      ...jobProfile,
      mustHaveRequirements: [...jobProfile.mustHaveRequirements, newMustHave.trim()]
    });
    setNewMustHave('');
  };

  const removeMustHave = (index: number) => {
    setJobProfile({
      ...jobProfile,
      mustHaveRequirements: jobProfile.mustHaveRequirements.filter((_, i) => i !== index)
    });
  };

  const addNiceToHave = () => {
    if (!newNiceToHave.trim()) return;
    setJobProfile({
      ...jobProfile,
      niceToHaveRequirements: [...jobProfile.niceToHaveRequirements, newNiceToHave.trim()]
    });
    setNewNiceToHave('');
  };

  const removeNiceToHave = (index: number) => {
    setJobProfile({
      ...jobProfile,
      niceToHaveRequirements: jobProfile.niceToHaveRequirements.filter((_, i) => i !== index)
    });
  };

  const addTech = () => {
    if (!newTech.trim()) return;
    setJobProfile({
      ...jobProfile,
      coreTechStack: [...jobProfile.coreTechStack, newTech.trim()]
    });
    setNewTech('');
  };

  const removeTech = (index: number) => {
    setJobProfile({
      ...jobProfile,
      coreTechStack: jobProfile.coreTechStack.filter((_, i) => i !== index)
    });
  };

  const weights = jobProfile.scoringWeights;

  return (
    <div className="space-y-6">
      {/* Top Banner / Role Quick Presets */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center">
              <Briefcase className="w-5 h-5 mr-2 text-blue-600" />
              Target Role & Evaluation Rubric
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Select a pre-configured role archetype or paste your custom job description to generate custom 5-pillar weights and requirements.
            </p>
          </div>

          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Presets:</span>
            {SAMPLE_JOB_PROFILES.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleSelectPreset(preset)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  jobProfile.id === preset.id
                    ? 'bg-blue-600 text-white shadow-xs font-semibold'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {preset.title.split('(')[0].trim()}
              </button>
            ))}
          </div>
        </div>

        {/* AI Job Parser Input */}
        <div className="mt-5 pt-5 border-t border-slate-100">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            Paste Any Custom Job Description to Auto-Extract Rubric:
          </label>
          <div className="relative">
            <textarea
              id="input-custom-job-description"
              rows={3}
              value={rawJobText}
              onChange={(e) => setRawJobText(e.target.value)}
              placeholder="Paste raw job description here (e.g. Job Title, requirements, tech stack, responsibilities)..."
              className="w-full rounded-lg border border-slate-300 p-3 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-slate-50/50"
            />
            <div className="absolute right-3 bottom-3 flex items-center space-x-2">
              <button
                id="btn-ai-extract-rubric"
                onClick={handleAnalyzeJobText}
                disabled={isAnalyzing || !rawJobText.trim()}
                className="inline-flex items-center px-3.5 py-1.5 rounded-lg text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 transition-all shadow-xs"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                    Analyzing with Gemini 3.7...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 mr-1.5" />
                    Extract Rubric with AI
                  </>
                )}
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="mt-2 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
              {errorMsg}
            </div>
          )}
        </div>
      </div>

      {/* Structured Job Profile Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Job Details & Core Info (2 cols) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center uppercase tracking-wide">
              <Building className="w-4 h-4 mr-2 text-blue-600" />
              Role Metadata & Position Scope
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Job Title</label>
                <input
                  id="input-job-title"
                  type="text"
                  value={jobProfile.title}
                  onChange={(e) => setJobProfile({ ...jobProfile, title: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Company / Organization</label>
                <input
                  id="input-company-name"
                  type="text"
                  value={jobProfile.company}
                  onChange={(e) => setJobProfile({ ...jobProfile, company: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Location & Workplace Type</label>
                <div className="relative">
                  <MapPin className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={jobProfile.location}
                    onChange={(e) => setJobProfile({ ...jobProfile, location: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Seniority & Required Tenure</label>
                <div className="relative">
                  <Clock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={jobProfile.seniorityLevel}
                    onChange={(e) => setJobProfile({ ...jobProfile, seniorityLevel: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Executive Summary</label>
              <textarea
                rows={2}
                value={jobProfile.summary}
                onChange={(e) => setJobProfile({ ...jobProfile, summary: e.target.value })}
                className="w-full rounded-lg border border-slate-300 p-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Hard Must-Have Requirements */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center uppercase tracking-wide">
                <CheckCircle2 className="w-4 h-4 mr-2 text-emerald-600" />
                Hard Must-Have Prerequisites (Non-Negotiable Filters)
              </h3>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                {jobProfile.mustHaveRequirements.length} Criteria
              </span>
            </div>

            <div className="space-y-2">
              {jobProfile.mustHaveRequirements.map((req, idx) => (
                <div 
                  key={idx}
                  className="flex items-start justify-between p-3 rounded-lg bg-slate-50 border border-slate-200 hover:border-blue-300 transition-colors group"
                >
                  <div className="flex items-start space-x-2.5 text-xs text-slate-800">
                    <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="font-medium">{req}</span>
                  </div>
                  <button
                    onClick={() => removeMustHave(idx)}
                    className="text-slate-400 hover:text-rose-600 p-1 rounded-md transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Must-Have */}
            <div className="flex items-center space-x-2 pt-2">
              <input
                type="text"
                placeholder="Add a required must-have qualification..."
                value={newMustHave}
                onChange={(e) => setNewMustHave(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addMustHave()}
                className="flex-1 rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={addMustHave}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center transition-colors"
              >
                <Plus className="w-3.5 h-3.5 mr-1" />
                Add
              </button>
            </div>
          </div>

          {/* Nice-to-Have Requirements & Tech Stack */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center uppercase tracking-wide">
                <Code2 className="w-4 h-4 mr-2 text-blue-600" />
                Core Tech Stack & Nice-To-Haves
              </h3>
            </div>

            {/* Tech Stack Pills */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-2">Core Technologies & Tools:</label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {jobProfile.coreTechStack.map((tech, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200"
                  >
                    {tech}
                    <button
                      onClick={() => removeTech(idx)}
                      className="ml-1.5 text-blue-400 hover:text-blue-800"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="Add technology (e.g. Next.js 14, Qdrant, Docker)..."
                  value={newTech}
                  onChange={(e) => setNewTech(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addTech()}
                  className="flex-1 rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={addTech}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Nice to Haves List */}
            <div className="pt-3 border-t border-slate-100">
              <label className="block text-xs font-semibold text-slate-600 mb-2">Preferred / Nice-To-Have Skills:</label>
              <div className="space-y-1.5 mb-2">
                {jobProfile.niceToHaveRequirements.map((nice, idx) => (
                  <div 
                    key={idx}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700"
                  >
                    <span>• {nice}</span>
                    <button
                      onClick={() => removeNiceToHave(idx)}
                      className="text-slate-400 hover:text-rose-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="Add preferred nice-to-have qualification..."
                  value={newNiceToHave}
                  onChange={(e) => setNewNiceToHave(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addNiceToHave()}
                  className="flex-1 rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={addNiceToHave}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic 5-Pillar Scoring Rubric (1 col) in Dark Slate */}
        <div className="space-y-6">
          <div className="bg-slate-800 text-white rounded-xl p-6 shadow-xs border border-slate-700 space-y-6 sticky top-20">
            <div className="flex items-center justify-between border-b border-slate-700 pb-4">
              <div>
                <h3 className="text-sm font-bold flex items-center text-white uppercase tracking-wide">
                  <Sliders className="w-4 h-4 mr-2 text-blue-400" />
                  5-Pillar Scoring Rubric
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Weights dynamically compute match score
                </p>
              </div>
              <span className="text-xs font-extrabold px-2.5 py-1 rounded-full bg-slate-700 text-blue-300 border border-slate-600">
                100% Total
              </span>
            </div>

            {/* Sliders */}
            <div className="space-y-4">
              {/* 1. Technical Skills */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">1. Technical & Architectural Depth</span>
                  <span className="font-mono font-bold text-amber-400">
                    {Math.round(weights.technicalSkills * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="60"
                  value={Math.round(weights.technicalSkills * 100)}
                  onChange={(e) => handleWeightChange('technicalSkills', Number(e.target.value))}
                  className="w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
                />
                <p className="text-[11px] text-slate-400">FastAPI, Next.js 14, RAG, Qdrant, Docker</p>
              </div>

              {/* 2. Experience & Seniority */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">2. Experience & Seniority Level</span>
                  <span className="font-mono font-bold text-blue-400">
                    {Math.round(weights.experienceSeniority * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="50"
                  value={Math.round(weights.experienceSeniority * 100)}
                  onChange={(e) => handleWeightChange('experienceSeniority', Number(e.target.value))}
                  className="w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
                />
                <p className="text-[11px] text-slate-400">Years of tenure, production scale, system ownership</p>
              </div>

              {/* 3. Domain & Industry Fit */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">3. Domain & Industry Fit</span>
                  <span className="font-mono font-bold text-emerald-400">
                    {Math.round(weights.domainIndustryFit * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="40"
                  value={Math.round(weights.domainIndustryFit * 100)}
                  onChange={(e) => handleWeightChange('domainIndustryFit', Number(e.target.value))}
                  className="w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
                />
                <p className="text-[11px] text-slate-400">Enterprise AI copilots, latency, data privacy</p>
              </div>

              {/* 4. Soft Skills & Leadership */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">4. Soft Skills & Leadership</span>
                  <span className="font-mono font-bold text-purple-400">
                    {Math.round(weights.softSkillsLeadership * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="30"
                  value={Math.round(weights.softSkillsLeadership * 100)}
                  onChange={(e) => handleWeightChange('softSkillsLeadership', Number(e.target.value))}
                  className="w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
                />
                <p className="text-[11px] text-slate-400">Tech lead track, mentoring, cross-functional agility</p>
              </div>

              {/* 5. Education & Certifications */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">5. Education & Credentials</span>
                  <span className="font-mono font-bold text-pink-400">
                    {Math.round(weights.educationCertifications * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="25"
                  value={Math.round(weights.educationCertifications * 100)}
                  onChange={(e) => handleWeightChange('educationCertifications', Number(e.target.value))}
                  className="w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
                />
                <p className="text-[11px] text-slate-400">STEM CS degrees, publications, cloud certifications</p>
              </div>
            </div>

            {/* Action CTA to Step 2 */}
            <div className="pt-4 border-t border-slate-700">
              <button
                id="btn-proceed-to-resumes"
                onClick={onProceedToResumes}
                className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg shadow-xs transition-all flex items-center justify-center space-x-2 uppercase tracking-wider"
              >
                <span>Proceed to Step 2: Ingest Resumes</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
