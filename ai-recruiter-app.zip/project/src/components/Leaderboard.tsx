import React, { useState, useMemo } from 'react';
import { 
  Trophy, 
  Award, 
  Search, 
  Filter, 
  ArrowUpDown, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  ChevronRight, 
  Mail, 
  FileText, 
  Sparkles, 
  TrendingUp, 
  Users, 
  HelpCircle,
  ExternalLink,
  ShieldAlert,
  Clock,
  ChevronDown
} from 'lucide-react';
import { CandidateEvaluation, RankingReport, RankingTier, RecommendationVerdict } from '../types';

interface LeaderboardProps {
  report: RankingReport;
  onSelectCandidate: (candidate: CandidateEvaluation) => void;
  onOpenInterviewKit: (candidate: CandidateEvaluation) => void;
  onOpenOutreachEmail: (candidate: CandidateEvaluation) => void;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({
  report,
  onSelectCandidate,
  onOpenInterviewKit,
  onOpenOutreachEmail
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTier, setSelectedTier] = useState<string>('ALL');
  const [selectedVerdict, setSelectedVerdict] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'matchScore' | 'technical' | 'experience' | 'domain' | 'leadership'>('matchScore');
  const [viewMode, setViewMode] = useState<'table' | 'detailed'>('table');

  // Filter & Sort Candidates
  const filteredCandidates = useMemo(() => {
    return report.candidates
      .filter((c) => {
        // Search query filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesName = c.name.toLowerCase().includes(q);
          const matchesRole = c.currentRole.toLowerCase().includes(q);
          const matchesSummary = c.executiveSummary.toLowerCase().includes(q);
          const matchesStrengths = c.keyStrengths.some((s) => s.toLowerCase().includes(q));
          if (!matchesName && !matchesRole && !matchesSummary && !matchesStrengths) {
            return false;
          }
        }

        // Tier filter
        if (selectedTier !== 'ALL' && c.tier !== selectedTier) {
          return false;
        }

        // Verdict filter
        if (selectedVerdict !== 'ALL' && c.recommendationVerdict !== selectedVerdict) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'matchScore') return b.matchScore - a.matchScore;
        if (sortBy === 'technical') return (b.dimensions?.technicalSkills?.score || 0) - (a.dimensions?.technicalSkills?.score || 0);
        if (sortBy === 'experience') return (b.dimensions?.experienceSeniority?.score || 0) - (a.dimensions?.experienceSeniority?.score || 0);
        if (sortBy === 'domain') return (b.dimensions?.domainIndustryFit?.score || 0) - (a.dimensions?.domainIndustryFit?.score || 0);
        if (sortBy === 'leadership') return (b.dimensions?.softSkillsLeadership?.score || 0) - (a.dimensions?.softSkillsLeadership?.score || 0);
        return 0;
      });
  }, [report.candidates, searchQuery, selectedTier, selectedVerdict, sortBy]);

  const topCandidate = report.candidates[0];

  const getTierBadge = (tier: RankingTier) => {
    switch (tier) {
      case 'TIER_1_TOP_SHORTLIST':
        return {
          label: 'Tier 1: Shortlist',
          className: 'px-2 py-1 bg-green-100 text-green-700 text-[10px] font-bold rounded uppercase tracking-wider'
        };
      case 'TIER_2_STRONG_CONTENDER':
        return {
          label: 'Tier 2: Contender',
          className: 'px-2 py-1 bg-blue-100 text-blue-700 text-[10px] font-bold rounded uppercase tracking-wider'
        };
      case 'TIER_3_HOLD_RESERVE':
        return {
          label: 'Tier 3: Hold',
          className: 'px-2 py-1 bg-amber-100 text-amber-700 text-[10px] font-bold rounded uppercase tracking-wider'
        };
      case 'TIER_4_DO_NOT_PROCEED':
        return {
          label: 'Tier 4: Reject',
          className: 'px-2 py-1 bg-slate-100 text-slate-600 text-[10px] font-bold rounded uppercase tracking-wider'
        };
      default:
        return {
          label: tier,
          className: 'px-2 py-1 bg-slate-100 text-slate-600 text-[10px] font-bold rounded uppercase tracking-wider'
        };
    }
  };

  const getVerdictStyle = (verdict: RecommendationVerdict) => {
    switch (verdict) {
      case 'Strong Hire':
        return 'text-green-700 font-semibold';
      case 'Hire':
        return 'text-emerald-700 font-semibold';
      case 'Leaning Hire':
        return 'text-amber-700 font-semibold';
      case 'Hold / Re-evaluate':
        return 'text-amber-600 font-semibold';
      case 'Reject':
        return 'text-slate-400 font-medium';
      default:
        return 'text-slate-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* 4-Column Metric Cards Row - Exact Professional Polish Theme */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Candidates</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">
            {report.candidates.length < 10 ? `0${report.candidates.length}` : report.candidates.length}
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Avg. Match Score</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">
            {report.statistics.averageScore?.toFixed(1) || '0.0'}%
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Top Candidate</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">
            {report.statistics.topScore?.toFixed(1) || '0.0'}%
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Tier 1 Shortlist</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">
            {report.statistics.tierCounts.tier1 < 10 ? `0${report.statistics.tierCounts.tier1}` : report.statistics.tierCounts.tier1}
          </p>
        </div>
      </div>

      {/* Filter and View Switcher Toolbar */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Search bar */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search candidate, role, or skillset..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-md border border-slate-300 pl-9 pr-3.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50/50"
          />
        </div>

        {/* Filters & Sorting */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Tier Filter */}
          <div className="flex items-center space-x-1.5 text-xs">
            <span className="text-slate-500 font-medium">Tier:</span>
            <select
              value={selectedTier}
              onChange={(e) => setSelectedTier(e.target.value)}
              className="rounded-md border border-slate-300 px-2.5 py-1.5 text-xs text-slate-800 bg-white font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="ALL">All Tiers ({report.candidates.length})</option>
              <option value="TIER_1_TOP_SHORTLIST">Tier 1: Shortlist ({report.statistics.tierCounts.tier1})</option>
              <option value="TIER_2_STRONG_CONTENDER">Tier 2: Contenders ({report.statistics.tierCounts.tier2})</option>
              <option value="TIER_3_HOLD_RESERVE">Tier 3: Hold ({report.statistics.tierCounts.tier3})</option>
              <option value="TIER_4_DO_NOT_PROCEED">Tier 4: Reject ({report.statistics.tierCounts.tier4})</option>
            </select>
          </div>

          {/* Sort Criteria */}
          <div className="flex items-center space-x-1.5 text-xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="rounded-md border border-slate-300 px-2.5 py-1.5 text-xs text-slate-800 bg-white font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="matchScore">Sort: Overall Score</option>
              <option value="technical">Sort: Technical Depth</option>
              <option value="experience">Sort: Experience</option>
              <option value="domain">Sort: Domain Fit</option>
              <option value="leadership">Sort: Leadership</option>
            </select>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-md border border-slate-200 text-xs">
            <button
              onClick={() => setViewMode('table')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                viewMode === 'table' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Table
            </button>
            <button
              onClick={() => setViewMode('detailed')}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                viewMode === 'detailed' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Cards
            </button>
          </div>
        </div>
      </div>

      {/* Main Ranking Leaderboard Box */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden flex flex-col">
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3.5 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wide">
            Ranking Leaderboard
          </h2>
          <span className="text-xs text-slate-500 font-medium">
            Showing {filteredCandidates.length} evaluated profiles
          </span>
        </div>

        {viewMode === 'table' ? (
          /* Table View matching the Professional Polish mockup */
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-white sticky top-0 z-10">
                <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <th className="px-6 py-4">Rank</th>
                  <th className="px-6 py-4">Candidate Info</th>
                  <th className="px-6 py-4">Match Score</th>
                  <th className="px-6 py-4">Tier</th>
                  <th className="px-6 py-4">Verdict</th>
                  <th className="px-6 py-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="text-sm divide-y divide-slate-100">
                {filteredCandidates.map((candidate, idx) => {
                  const isTopRank = idx === 0;
                  const tierBadge = getTierBadge(candidate.tier);
                  const scoreColor = candidate.matchScore >= 85 
                    ? 'bg-green-500 text-green-600' 
                    : candidate.matchScore >= 65 
                    ? 'bg-amber-500 text-amber-600' 
                    : 'bg-red-500 text-red-500';

                  return (
                    <tr 
                      key={candidate.id}
                      className={`transition-colors ${
                        isTopRank ? 'bg-blue-50/30 hover:bg-blue-50/60' : 'hover:bg-slate-50/80'
                      }`}
                    >
                      {/* Rank Number */}
                      <td className="px-6 py-4">
                        <span className={`text-lg font-bold ${isTopRank ? 'text-blue-600' : 'text-slate-400'}`}>
                          #{idx + 1}
                        </span>
                      </td>

                      {/* Candidate Info */}
                      <td className="px-6 py-4">
                        <div>
                          <p 
                            onClick={() => onSelectCandidate(candidate)}
                            className="font-bold text-slate-800 hover:text-blue-600 cursor-pointer transition-colors"
                          >
                            {candidate.name}
                          </p>
                          <p className="text-xs text-slate-500 mt-0.5">
                            {candidate.currentRole} {candidate.currentCompany ? `• @${candidate.currentCompany}` : ''}
                          </p>
                        </div>
                      </td>

                      {/* Match Score with Progress Bar */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-24 h-2 bg-slate-200 rounded-full overflow-hidden shrink-0">
                            <div 
                              className={`h-full ${candidate.matchScore >= 80 ? 'bg-green-500' : candidate.matchScore >= 60 ? 'bg-amber-500' : 'bg-red-400'}`}
                              style={{ width: `${candidate.matchScore}%` }}
                            />
                          </div>
                          <span className={`font-bold text-xs ${candidate.matchScore >= 80 ? 'text-green-600' : candidate.matchScore >= 60 ? 'text-amber-600' : 'text-red-500'}`}>
                            {candidate.matchScore.toFixed(1)}%
                          </span>
                        </div>
                      </td>

                      {/* Tier Badge */}
                      <td className="px-6 py-4">
                        <span className={tierBadge.className}>
                          {tierBadge.label}
                        </span>
                      </td>

                      {/* Verdict */}
                      <td className="px-6 py-4 text-xs font-medium">
                        <span className={getVerdictStyle(candidate.recommendationVerdict)}>
                          {candidate.recommendationVerdict}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-3">
                          <button
                            onClick={() => onOpenInterviewKit(candidate)}
                            className="text-xs text-slate-600 hover:text-blue-600 font-medium transition-colors"
                            title="Interview Kit"
                          >
                            Kit
                          </button>
                          <button
                            onClick={() => onSelectCandidate(candidate)}
                            className="text-xs text-blue-600 font-bold hover:underline hover:text-blue-700"
                          >
                            View Dossier
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          /* Detailed Cards Grid */
          <div className="p-6 space-y-4">
            {filteredCandidates.map((candidate, idx) => {
              const tierBadge = getTierBadge(candidate.tier);
              const metCount = candidate.mustHaveChecks.filter((m) => m.status === 'MET').length;
              const totalMust = candidate.mustHaveChecks.length;

              return (
                <div
                  key={candidate.id}
                  className={`p-5 rounded-xl border transition-all ${
                    idx === 0
                      ? 'border-blue-300 bg-blue-50/20 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 shadow-2xs'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <span className={`text-xl font-bold ${idx === 0 ? 'text-blue-600' : 'text-slate-400'}`}>
                        #{idx + 1}
                      </span>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 
                            onClick={() => onSelectCandidate(candidate)}
                            className="text-base font-bold text-slate-900 hover:text-blue-600 cursor-pointer"
                          >
                            {candidate.name}
                          </h3>
                          <span className={tierBadge.className}>{tierBadge.label}</span>
                          <span className={`text-xs ${getVerdictStyle(candidate.recommendationVerdict)}`}>
                            {candidate.recommendationVerdict}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          {candidate.currentRole} • {candidate.totalExperienceYears} yrs experience • {candidate.email}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 self-end sm:self-center">
                      <div className="text-right pr-3 border-r border-slate-200">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Match</span>
                        <span className="text-xl font-bold text-blue-600">{candidate.matchScore.toFixed(1)}%</span>
                      </div>
                      <button
                        onClick={() => onOpenInterviewKit(candidate)}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold transition-colors"
                      >
                        Interview Kit
                      </button>
                      <button
                        onClick={() => onSelectCandidate(candidate)}
                        className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold transition-colors"
                      >
                        Dossier
                      </button>
                    </div>
                  </div>

                  {/* Summary Snippet */}
                  <p className="text-xs text-slate-600 mt-3 pt-3 border-t border-slate-100 leading-relaxed">
                    {candidate.executiveSummary}
                  </p>

                  {/* Sub-Dimension Scores */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3 pt-2 text-xs">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase font-semibold">Technical</span>
                      <div className="font-bold text-slate-800">{candidate.dimensions?.technicalSkills?.score || 0}/100</div>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase font-semibold">Seniority</span>
                      <div className="font-bold text-slate-800">{candidate.dimensions?.experienceSeniority?.score || 0}/100</div>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase font-semibold">Domain Fit</span>
                      <div className="font-bold text-slate-800">{candidate.dimensions?.domainIndustryFit?.score || 0}/100</div>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase font-semibold">Must Haves</span>
                      <div className="font-bold text-emerald-700">{metCount}/{totalMust} Met</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom Split Section: Executive Summary & Dark Interview Pulse */}
      {topCandidate && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Executive Summary of Top Candidate */}
          <div className="lg:col-span-2 bg-white p-5 rounded-xl shadow-xs border border-slate-200 flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
                Executive Summary ({topCandidate.name})
              </h3>
              <div className="text-sm text-slate-600 leading-relaxed space-y-3">
                <p>{topCandidate.executiveSummary}</p>
                <div className="pt-2 border-t border-slate-100">
                  <p className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Verified Competencies</p>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {topCandidate.keyStrengths.slice(0, 4).map((str, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-slate-700">
                        <span className="w-1.5 h-1.5 bg-blue-500 rounded-full shrink-0" />
                        <span className="truncate">{str}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-500 italic">
                Ranked #1 with {topCandidate.matchScore.toFixed(1)}% match score
              </span>
              <button
                onClick={() => onSelectCandidate(topCandidate)}
                className="text-xs font-bold text-blue-600 hover:text-blue-700 hover:underline"
              >
                View Full Scorecard →
              </button>
            </div>
          </div>

          {/* Dark Interview Pulse Widget */}
          <div className="bg-slate-800 p-5 rounded-xl shadow-xs text-white flex flex-col justify-between border border-slate-700">
            <div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                Interview Pulse
              </h3>
              <div className="space-y-3">
                <div className="p-2.5 bg-slate-700/80 rounded-lg border border-slate-600/50">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider">Key Area to Probe</p>
                  <p className="text-xs font-medium text-slate-200 mt-0.5 leading-snug">
                    {topCandidate.interviewKit?.[0]?.question || 'Experience with high-throughput production architectures.'}
                  </p>
                </div>

                <div className="p-2.5 bg-slate-700/80 rounded-lg border border-slate-600/50">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider">Potential Red Flag</p>
                  <p className="text-xs font-medium text-slate-200 mt-0.5 leading-snug">
                    {topCandidate.riskFactors?.[0] || 'Clarify scope of individual contributions vs team deliverables.'}
                  </p>
                </div>
              </div>
            </div>

            <button
              onClick={() => onOpenInterviewKit(topCandidate)}
              className="w-full mt-4 py-2 bg-blue-500 hover:bg-blue-400 text-white text-xs font-bold rounded-lg transition-colors uppercase tracking-widest shadow-2xs"
            >
              Generate Interview Guide
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

