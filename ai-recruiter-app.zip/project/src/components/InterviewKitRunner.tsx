import React, { useState } from 'react';
import { 
  HelpCircle, 
  CheckCircle2, 
  AlertTriangle, 
  Star, 
  Copy, 
  Check, 
  X, 
  User, 
  Sparkles,
  Download,
  Save
} from 'lucide-react';
import { CandidateEvaluation, InterviewProbe } from '../types';

interface InterviewKitRunnerProps {
  candidate: CandidateEvaluation;
  onClose: () => void;
}

export const InterviewKitRunner: React.FC<InterviewKitRunnerProps> = ({
  candidate,
  onClose
}) => {
  const [ratings, setRatings] = useState<Record<string, number>>({});
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [checkedSignals, setCheckedSignals] = useState<Record<string, boolean>>({});
  const [checkedRedFlags, setCheckedRedFlags] = useState<Record<string, boolean>>({});
  const [overallVerdict, setOverallVerdict] = useState<string>('RECOMMEND_PROCEED');
  const [copied, setCopied] = useState<boolean>(false);

  const probes = candidate.interviewKit || [];

  const handleRating = (probeId: string, rating: number) => {
    setRatings((prev) => ({ ...prev, [probeId]: rating }));
  };

  const handleNotesChange = (probeId: string, text: string) => {
    setNotes((prev) => ({ ...prev, [probeId]: text }));
  };

  const toggleSignal = (key: string) => {
    setCheckedSignals((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleRedFlag = (key: string) => {
    setCheckedRedFlags((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Calculate average rating
  const ratingValues = Object.values(ratings) as number[];
  const avgRating = ratingValues.length > 0
    ? (ratingValues.reduce((a: number, b: number) => a + b, 0) / ratingValues.length).toFixed(1)
    : 'N/A';

  const exportInterviewNotes = () => {
    const lines = [
      `# Live Interview Screen Notes: ${candidate.name}`,
      `**Role:** ${candidate.currentRole} | **Initial Match Score:** ${candidate.matchScore.toFixed(1)}%`,
      `**Interview Date:** ${new Date().toLocaleDateString()}`,
      `**Overall Screen Rating:** ${avgRating} / 5.0 | **Screen Verdict:** ${overallVerdict}`,
      '',
      '## Detailed Probe Responses:',
      ...probes.map((p, idx) => {
        const id = p.id || `probe-${idx}`;
        const score = ratings[id] || 'Unrated';
        const userNotes = notes[id] || 'None recorded.';
        return `### Question ${idx + 1}: ${p.question}\n- **Intent:** ${p.intent}\n- **Score:** ${score} / 5\n- **Notes:** ${userNotes}\n`;
      })
    ];

    const markdownText = lines.join('\n');
    navigator.clipboard.writeText(markdownText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Top Header */}
        <div className="p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-bold text-white tracking-tight">Live Phone Screen Interview Kit</h2>
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-800 text-blue-400 border border-slate-700">
                  {candidate.name}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Initial Match Score: <strong className="text-emerald-400 font-mono">{candidate.matchScore.toFixed(1)}%</strong> • {candidate.currentRole}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Stats Bar */}
        <div className="px-5 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center space-x-4">
            <span className="text-slate-600">
              <strong>Probes:</strong> {probes.length} Questions
            </span>
            <span className="text-slate-600">
              <strong>Screen Average Score:</strong>{' '}
              <span className="font-mono font-bold text-blue-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                {avgRating} / 5.0
              </span>
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <span className="font-semibold text-slate-700 text-xs">Interview Verdict:</span>
            <select
              value={overallVerdict}
              onChange={(e) => setOverallVerdict(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-2.5 py-1 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500"
            >
              <option value="STRONG_ADVANCE">Strong Advance to Onsite</option>
              <option value="RECOMMEND_PROCEED">Recommend Proceed</option>
              <option value="BORDERLINE_NEED_DEEPER_TECH">Borderline (Needs Deeper Tech Probe)</option>
              <option value="REJECT_POST_SCREEN">Reject Post-Screen</option>
            </select>
          </div>
        </div>

        {/* Probes List */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {probes.map((probe, idx) => {
            const id = probe.id || `probe-${idx}`;
            const currentRating = ratings[id] || 0;

            return (
              <div 
                key={id}
                className="p-4 rounded-xl border border-slate-200 bg-white space-y-3 shadow-2xs"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center space-x-2">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                      {probe.category}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                      {probe.difficulty}
                    </span>
                  </div>

                  {/* Rating Selector */}
                  <div className="flex items-center space-x-1">
                    <span className="text-[11px] font-bold text-slate-500 mr-1 uppercase">Rating:</span>
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => handleRating(id, star)}
                        className={`p-1 rounded transition-colors ${
                          currentRating >= star ? 'text-amber-500' : 'text-slate-300 hover:text-amber-400'
                        }`}
                      >
                        <Star className="w-3.5 h-3.5 fill-current" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Question */}
                <div>
                  <h3 className="text-xs font-bold text-slate-900 leading-snug">
                    "{probe.question}"
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    <strong>Intent:</strong> {probe.intent}
                  </p>
                </div>

                {/* Signals Checklist */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1 text-xs">
                  {/* Positive checklist */}
                  <div className="p-3 rounded-lg bg-emerald-50/50 border border-emerald-100 space-y-1.5">
                    <span className="text-[10px] font-bold text-emerald-900 uppercase tracking-wider block">
                      Listen for Positive Signals:
                    </span>
                    {probe.positiveSignals?.map((sig, sIdx) => {
                      const sigKey = `${id}-pos-${sIdx}`;
                      return (
                        <label 
                          key={sIdx} 
                          className="flex items-start space-x-2 cursor-pointer select-none text-slate-800 text-[11px]"
                        >
                          <input
                            type="checkbox"
                            checked={!!checkedSignals[sigKey]}
                            onChange={() => toggleSignal(sigKey)}
                            className="mt-0.5 accent-emerald-600 rounded"
                          />
                          <span className={checkedSignals[sigKey] ? 'line-through text-slate-400' : ''}>
                            {sig}
                          </span>
                        </label>
                      );
                    })}
                  </div>

                  {/* Red flags checklist */}
                  <div className="p-3 rounded-lg bg-rose-50/50 border border-rose-100 space-y-1.5">
                    <span className="text-[10px] font-bold text-rose-900 uppercase tracking-wider block">
                      Watch for Red Flags:
                    </span>
                    {probe.redFlagSignals?.map((red, rIdx) => {
                      const redKey = `${id}-red-${rIdx}`;
                      return (
                        <label 
                          key={rIdx} 
                          className="flex items-start space-x-2 cursor-pointer select-none text-slate-800 text-[11px]"
                        >
                          <input
                            type="checkbox"
                            checked={!!checkedRedFlags[redKey]}
                            onChange={() => toggleRedFlag(redKey)}
                            className="mt-0.5 accent-rose-600 rounded"
                          />
                          <span className={checkedRedFlags[redKey] ? 'font-bold text-rose-700' : ''}>
                            {red}
                          </span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                {/* Candidate Response Notes */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Candidate Response Notes:
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Type candidate responses, architectural choices mentioned, or concerns..."
                    value={notes[id] || ''}
                    onChange={(e) => handleNotesChange(id, e.target.value)}
                    className="w-full rounded-lg border border-slate-300 p-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 bg-white"
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Ratings and notes can be exported directly to hiring team
          </span>

          <div className="flex items-center space-x-2">
            <button
              onClick={exportInterviewNotes}
              className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 transition-colors flex items-center space-x-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard' : 'Copy Interview Report'}</span>
            </button>

            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 transition-colors"
            >
              Save & Exit Screen
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
