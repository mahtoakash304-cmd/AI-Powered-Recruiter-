import React, { useState } from 'react';
import { 
  Users, 
  UploadCloud, 
  Plus, 
  Trash2, 
  Sparkles, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  Loader2, 
  ArrowRight,
  Eye,
  RefreshCw
} from 'lucide-react';
import { ResumeInput, JobProfile } from '../types';
import { SAMPLE_RESUME_TEXTS } from '../data/sampleData';

interface ResumeIngestionProps {
  resumes: ResumeInput[];
  setResumes: React.Dispatch<React.SetStateAction<ResumeInput[]>>;
  jobProfile: JobProfile;
  onRunBatchEvaluation: () => void;
  isEvaluating: boolean;
  evaluationProgress: { current: number; total: number; currentCandidateName?: string };
}

export const ResumeIngestion: React.FC<ResumeIngestionProps> = ({
  resumes,
  setResumes,
  jobProfile,
  onRunBatchEvaluation,
  isEvaluating,
  evaluationProgress
}) => {
  const [manualName, setManualName] = useState<string>('');
  const [manualContent, setManualContent] = useState<string>('');
  const [activePreviewResume, setActivePreviewResume] = useState<ResumeInput | null>(null);
  const [dragOver, setDragOver] = useState<boolean>(false);

  // Load benchmark 5 candidates
  const loadBenchmarkCandidates = () => {
    const benchmarkList: ResumeInput[] = [
      {
        id: 'bench-elena',
        name: 'Elena Rostova',
        fileName: 'elena_rostova_staff_ai_lead.txt',
        content: SAMPLE_RESUME_TEXTS.elena_rostova,
        status: 'idle'
      },
      {
        id: 'bench-amina',
        name: 'Amina Al-Mansoor',
        fileName: 'amina_al_mansoor_senior_ai_biomed.txt',
        content: SAMPLE_RESUME_TEXTS.amina_al_mansoor,
        status: 'idle'
      },
      {
        id: 'bench-marcus',
        name: 'Marcus Chen',
        fileName: 'marcus_chen_lead_backend_infra.txt',
        content: SAMPLE_RESUME_TEXTS.marcus_chen,
        status: 'idle'
      },
      {
        id: 'bench-sarah',
        name: 'Sarah Jenkins',
        fileName: 'sarah_jenkins_frontend_ai_agency.txt',
        content: SAMPLE_RESUME_TEXTS.sarah_jenkins,
        status: 'idle'
      },
      {
        id: 'bench-david',
        name: 'David Miller',
        fileName: 'david_miller_enterprise_java_dev.txt',
        content: SAMPLE_RESUME_TEXTS.david_miller,
        status: 'idle'
      }
    ];
    setResumes(benchmarkList);
  };

  // Add manually pasted resume
  const handleAddManualResume = () => {
    if (!manualContent.trim()) return;
    const name = manualName.trim() || manualContent.split('\n')[0].replace(/[#*]/g, '').trim() || `Candidate ${resumes.length + 1}`;
    
    const newResume: ResumeInput = {
      id: 'res-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 5),
      name,
      fileName: `${name.toLowerCase().replace(/\s+/g, '_')}_resume.txt`,
      content: manualContent.trim(),
      status: 'idle'
    };

    setResumes([...resumes, newResume]);
    setManualName('');
    setManualContent('');
  };

  const MAX_FILE_BYTES = 8 * 1024 * 1024; // 8MB, mirrors the server-side limit
  const TEXT_EXTENSIONS = ['txt', 'md', 'text', 'json'];
  const BINARY_EXTENSIONS = ['pdf', 'docx'];

  const getExtension = (fileName: string) => fileName.toLowerCase().split('.').pop() || '';

  const updateResumeById = (id: string, patch: Partial<ResumeInput>) => {
    setResumes((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  };

  const arrayBufferToBase64 = (buffer: ArrayBuffer): string => {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return btoa(binary);
  };

  // File upload handling. Plain-text formats are read directly in-browser.
  // PDF/DOCX are binary formats — FileReader.readAsText() on them produces
  // garbage/mojibake, not real content — so those are sent to the backend
  // for proper extraction via pdf-parse / mammoth.
  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const ext = getExtension(file.name);

      if (!TEXT_EXTENSIONS.includes(ext) && !BINARY_EXTENSIONS.includes(ext)) {
        alert(`"${file.name}" was skipped: unsupported file type ".${ext}". Supported types: .txt, .md, .json, .pdf, .docx`);
        return;
      }
      if (file.size === 0) {
        alert(`"${file.name}" was skipped: the file is empty.`);
        return;
      }
      if (file.size > MAX_FILE_BYTES) {
        alert(`"${file.name}" was skipped: exceeds the ${(MAX_FILE_BYTES / (1024 * 1024)).toFixed(0)}MB upload limit.`);
        return;
      }

      const id = 'file-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 5);
      const defaultName = file.name.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');

      if (TEXT_EXTENSIONS.includes(ext)) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const text = (e.target?.result as string) || '';
          if (!text.trim()) {
            alert(`"${file.name}" appears to be empty after reading — nothing was added.`);
            return;
          }
          const extractedName = text.split('\n')[0]?.replace(/[#*]/g, '').trim() || defaultName;
          setResumes((prev) => [
            ...prev,
            { id, name: extractedName, fileName: file.name, content: text, status: 'idle' }
          ]);
        };
        reader.onerror = () => {
          alert(`Failed to read "${file.name}". The file may be corrupted or unreadable.`);
        };
        reader.readAsText(file);
        return;
      }

      // Binary formats: show a "parsing" placeholder immediately, then swap
      // it for real content (or an error) once the server responds.
      setResumes((prev) => [
        ...prev,
        { id, name: defaultName, fileName: file.name, content: '', status: 'parsing' }
      ]);

      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const buffer = e.target?.result as ArrayBuffer;
          const fileBase64 = arrayBufferToBase64(buffer);

          const res = await fetch('/api/parse-resume', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fileName: file.name, fileBase64 })
          });

          const data = await res.json().catch(() => ({}));

          if (!res.ok) {
            throw new Error(data.error || `Failed to parse "${file.name}".`);
          }

          const extractedName = data.text.split('\n')[0]?.replace(/[#*]/g, '').trim() || defaultName;
          updateResumeById(id, { name: extractedName, content: data.text, status: 'idle', error: undefined });
        } catch (err: any) {
          console.error('Resume parse error:', err);
          updateResumeById(id, { status: 'error', error: err.message || 'Failed to parse file.' });
        }
      };
      reader.onerror = () => {
        updateResumeById(id, { status: 'error', error: 'Failed to read file from disk.' });
      };
      reader.readAsArrayBuffer(file);
    });
  };

  const removeResume = (id: string) => {
    setResumes(resumes.filter((r) => r.id !== id));
  };

  const clearAllResumes = () => {
    setResumes([]);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center">
              <Users className="w-5 h-5 mr-2 text-blue-600" />
              Candidate Ingestion & Batch Queue
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-blue-50 text-blue-700 border border-blue-200">
              {resumes.length} Ingested
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Evaluating against target position: <strong className="text-slate-800">{jobProfile.title}</strong>
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            id="btn-load-5-benchmark-candidates"
            onClick={loadBenchmarkCandidates}
            disabled={isEvaluating}
            className="px-3.5 py-2 rounded-lg text-xs font-bold text-blue-700 bg-blue-50 border border-blue-200 hover:bg-blue-100 transition-colors flex items-center space-x-1.5 shadow-2xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Load 5 Benchmark Resumes</span>
          </button>

          {resumes.length > 0 && (
            <button
              onClick={clearAllResumes}
              disabled={isEvaluating}
              className="px-3 py-2 rounded-lg text-xs font-medium text-slate-600 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 transition-colors"
            >
              Clear All
            </button>
          )}
        </div>
      </div>

      {/* Evaluating Progress Banner */}
      {isEvaluating && (
        <div className="bg-slate-800 text-white rounded-xl p-5 shadow-xs border border-slate-700 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Loader2 className="w-5 h-5 text-blue-400 animate-spin" />
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wide">
                  Running Multi-Dimensional Gemini Evaluation...
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Currently evaluating profile {evaluationProgress.current} of {evaluationProgress.total}:{' '}
                  <strong className="text-blue-300">{evaluationProgress.currentCandidateName || 'Evaluating...'}</strong>
                </p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-blue-300">
              {Math.round((evaluationProgress.current / Math.max(1, evaluationProgress.total)) * 100)}%
            </span>
          </div>

          <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
            <div 
              className="bg-blue-500 h-2 transition-all duration-300 rounded-full"
              style={{ width: `${(evaluationProgress.current / Math.max(1, evaluationProgress.total)) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Upload and Paste Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Drag and Drop File Upload */}
        <div 
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            handleFileUpload(e.dataTransfer.files);
          }}
          className={`border-2 border-dashed rounded-xl p-8 text-center flex flex-col items-center justify-center transition-all bg-white ${
            dragOver ? 'border-blue-600 bg-blue-50/50 scale-[0.99]' : 'border-slate-300 hover:border-blue-400'
          }`}
        >
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
            <UploadCloud className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide">Upload Resume Files</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xs">
            Drag & drop text, markdown, PDF, or Word (.docx) resumes here, or browse files. Max 8MB per file.
          </p>

          <label className="mt-4 cursor-pointer">
            <span className="px-4 py-2 rounded-lg text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors shadow-xs">
              Select Files
            </span>
            <input
              type="file"
              multiple
              accept=".txt,.md,.text,.json,.pdf,.docx"
              onChange={(e) => { handleFileUpload(e.target.files); e.target.value = ''; }}
              className="hidden"
            />
          </label>
        </div>

        {/* Manual Resume Paste */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-800 flex items-center uppercase tracking-wide">
            <FileText className="w-4 h-4 mr-2 text-blue-600" />
            Paste Candidate Resume
          </h3>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Candidate Full Name (Optional)</label>
            <input
              id="input-candidate-name"
              type="text"
              placeholder="e.g. Alex Morgan"
              value={manualName}
              onChange={(e) => setManualName(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Resume Text Content</label>
            <textarea
              id="input-resume-text"
              rows={4}
              placeholder="Paste full resume text (experience, skills, education, projects)..."
              value={manualContent}
              onChange={(e) => setManualContent(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-blue-500 font-mono"
            />
          </div>

          <div className="flex justify-end">
            <button
              id="btn-add-candidate-to-queue"
              onClick={handleAddManualResume}
              disabled={!manualContent.trim()}
              className="px-4 py-2 rounded-lg text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-40 transition-colors flex items-center space-x-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Candidate to Ingestion Queue</span>
            </button>
          </div>
        </div>
      </div>

      {/* Ingested Resumes List */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 flex items-center uppercase tracking-wide">
            <Users className="w-4 h-4 mr-2 text-blue-600" />
            Candidate Queue Ready for Evaluation ({resumes.length})
          </h3>

          {resumes.length > 0 && (
            <button
              id="btn-trigger-ai-ranking"
              onClick={onRunBatchEvaluation}
              disabled={isEvaluating}
              className="px-4 py-2 rounded-lg text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-all shadow-xs flex items-center space-x-2 disabled:opacity-50 group uppercase tracking-wider"
            >
              <Sparkles className="w-4 h-4" />
              <span>Run AI Evaluation & Rank ({resumes.length} Profiles)</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          )}
        </div>

        {resumes.length === 0 ? (
          <div className="py-12 text-center text-slate-400 space-y-3">
            <Users className="w-12 h-12 mx-auto text-slate-300" />
            <p className="text-sm font-medium">No candidate resumes in queue.</p>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Click <strong>"Load 5 Benchmark Resumes"</strong> above to load the realistic benchmark dataset, or upload custom resumes.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {resumes.map((resume, idx) => (
              <div 
                key={resume.id}
                className={`p-4 rounded-xl border transition-all space-y-3 shadow-2xs ${
                  resume.status === 'error'
                    ? 'border-rose-300 bg-rose-50/40'
                    : 'border-slate-200 bg-white hover:border-blue-300'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-700 text-[11px] font-bold flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <h4 className="font-bold text-xs text-slate-900 truncate max-w-[180px]">
                        {resume.name}
                      </h4>
                    </div>
                    {resume.fileName && (
                      <p className="text-[11px] text-slate-500 truncate mt-0.5">
                        {resume.fileName}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => setActivePreviewResume(resume)}
                      disabled={resume.status === 'parsing'}
                      className="p-1 text-slate-400 hover:text-blue-600 rounded transition-colors disabled:opacity-30"
                      title="Preview Resume"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => removeResume(resume.id)}
                      disabled={isEvaluating}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                      title="Remove"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {resume.status === 'parsing' ? (
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-500 flex items-center gap-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-500" />
                    Extracting text from file...
                  </div>
                ) : resume.status === 'error' ? (
                  <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-[11px] text-rose-700">
                    {resume.error || 'Failed to process this file.'}
                  </div>
                ) : (
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-600 font-mono line-clamp-3">
                    {resume.content.slice(0, 200)}...
                  </div>
                )}

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
                  <span>{resume.content.length.toLocaleString()} chars</span>
                  {resume.status === 'parsing' ? (
                    <span className="text-blue-600 font-medium flex items-center">
                      <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                      Parsing
                    </span>
                  ) : resume.status === 'error' ? (
                    <span className="text-rose-600 font-medium flex items-center">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      Failed
                    </span>
                  ) : (
                    <span className="text-emerald-700 font-medium flex items-center">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Ready
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Resume Preview Modal */}
      {activePreviewResume && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[80vh] flex flex-col shadow-2xl border border-slate-200">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900">{activePreviewResume.name}</h3>
                <p className="text-xs text-slate-500">{activePreviewResume.fileName || 'Resume Document'}</p>
              </div>
              <button
                onClick={() => setActivePreviewResume(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                ✕
              </button>
            </div>
            <div className="p-6 overflow-y-auto font-mono text-xs text-slate-800 whitespace-pre-wrap bg-slate-50 flex-1">
              {activePreviewResume.content}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
