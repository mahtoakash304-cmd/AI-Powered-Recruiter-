import React, { useState } from 'react';
import { 
  FileText, 
  Sparkles, 
  Copy, 
  Check, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  ArrowRight, 
  Trophy,
  Users,
  Target
} from 'lucide-react';
import { RankingReport, CandidateEvaluation } from '../types';

interface ExecutiveSummaryViewProps {
  report: RankingReport;
  onSelectCandidate: (candidate: CandidateEvaluation) => void;
}

export const ExecutiveSummaryView: React.FC<ExecutiveSummaryViewProps> = ({
  report,
  onSelectCandidate
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const briefing = report.executiveBriefing || {
    topCandidateHighlights: 'Top candidate matches are highlighted below.',
    marketFitAssessment: 'Diverse applicant pool evaluated against target criteria.',
    hiringRisksAndTradeoffs: 'Review tradeoffs between candidates.',
    recommendedNextSteps: []
  };
  const topCandidate = report.candidates[0];

  const handleCopyMemo = () => {
    const memo = `
# Executive Recruitment Briefing: ${report.jobProfile.title}
**Company:** ${report.jobProfile.company} | **Location:** ${report.jobProfile.location}
**Date:** ${new Date(report.evaluatedAt).toLocaleDateString()}

## Top Candidate Highlights
${briefing.topCandidateHighlights}

## Top Recommended Candidate
**Name:** ${topCandidate?.name} (${topCandidate?.currentRole})
**Match Score:** ${topCandidate?.matchScore.toFixed(1)}% - ${topCandidate?.recommendationVerdict}
**Verdict:** ${topCandidate?.keyVerdictHeadline}

## Strategic Hiring Tradeoffs
${briefing.hiringRisksAndTradeoffs}

## Market Assessment
${briefing.marketFitAssessment}

## Recommended Next Steps
${briefing.recommendedNextSteps?.map((s) => `[ ] ${s}`).join('\n')}
    `.trim();

    navigator.clipboard.writeText(memo);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center">
              <Sparkles className="w-5 h-5 mr-2 text-blue-600" />
              Executive Recruiter Memo & Strategic Synthesis
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-blue-50 text-blue-700 border border-blue-200">
              Gemini 3.7 Synthesized
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            High-level briefing tailored for VP of Engineering, Hiring Managers, and Talent Committees.
          </p>
        </div>

        <button
          onClick={handleCopyMemo}
          className="px-3.5 py-2 rounded-lg text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 transition-colors flex items-center space-x-1.5 shadow-2xs self-start md:self-auto"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Memo Copied!' : 'Copy Executive Memo'}</span>
        </button>
      </div>

      {/* Primary Summary & Top Recommendation Banner */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Overall Synthesis (2 cols) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-xs font-bold text-slate-900 flex items-center uppercase tracking-wider">
              <Target className="w-4 h-4 mr-2 text-blue-600" />
              Talent Pool Highlights & Top Candidate Review
            </h3>
            <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
              {briefing.topCandidateHighlights}
            </p>
          </div>

          {/* Tradeoffs & Hiring Considerations */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-slate-900 flex items-center text-amber-900 uppercase tracking-wider">
              <AlertTriangle className="w-4 h-4 mr-2 text-amber-600" />
              Strategic Hiring Tradeoffs & Candidate Dynamics
            </h3>
            <div className="p-4 rounded-lg bg-amber-50/50 border border-amber-200 text-xs text-amber-950 leading-relaxed">
              {briefing.hiringRisksAndTradeoffs}
            </div>
          </div>

          {/* Market Fit Assessment */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-slate-900 flex items-center uppercase tracking-wider">
              <TrendingUp className="w-4 h-4 mr-2 text-blue-600" />
              Talent Market & Compensation Dynamics
            </h3>
            <p className="text-xs text-slate-700 leading-relaxed">
              {briefing.marketFitAssessment}
            </p>
          </div>
        </div>

        {/* Right: Top Pick Highlight & Action Checklist (1 col) */}
        <div className="space-y-6">
          {/* Top Pick Highlight Card */}
          {topCandidate && (
            <div className="bg-slate-900 text-white rounded-xl p-6 shadow-xs space-y-4 border border-slate-800">
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-amber-400 text-slate-950 flex items-center">
                  <Trophy className="w-3 h-3 mr-1" />
                  #1 Top Match Candidate
                </span>
                <span className="text-xl font-bold font-mono text-emerald-400">
                  {topCandidate.matchScore.toFixed(1)}%
                </span>
              </div>

              <div>
                <h4 className="text-base font-bold text-white">{topCandidate.name}</h4>
                <p className="text-xs text-slate-400">{topCandidate.currentRole} • {topCandidate.totalExperienceYears} yrs exp</p>
              </div>

              <div className="p-3 rounded-lg bg-slate-800/80 text-xs text-slate-300 italic border border-slate-700">
                "{topCandidate.keyVerdictHeadline}"
              </div>

              <button
                onClick={() => onSelectCandidate(topCandidate)}
                className="w-full py-2 px-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs transition-colors flex items-center justify-center space-x-1.5 shadow-xs"
              >
                <span>View Full Candidate Dossier</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Next Steps Action Checklist */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-xs font-bold text-slate-900 flex items-center uppercase tracking-wider">
              <CheckCircle2 className="w-4 h-4 mr-2 text-emerald-600" />
              Recommended Immediate Actions
            </h3>
            <div className="space-y-2">
              {briefing.recommendedNextSteps?.map((step, idx) => (
                <div 
                  key={idx}
                  className="flex items-start space-x-2.5 text-xs text-slate-800 p-2.5 rounded-lg bg-slate-50 border border-slate-200"
                >
                  <span className="w-4 h-4 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    ✓
                  </span>
                  <span className="font-medium leading-tight">{step}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
