import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  Briefcase, 
  Layers, 
  Users, 
  CheckCircle2, 
  Sliders, 
  TrendingUp, 
  FileText, 
  Sparkles, 
  Download, 
  RotateCcw, 
  HelpCircle, 
  ShieldCheck,
  Menu,
  X,
  Play
} from 'lucide-react';
import { JobProfileEditor } from './components/JobProfileEditor';
import { ResumeIngestion } from './components/ResumeIngestion';
import { Leaderboard } from './components/Leaderboard';
import { CompetencyMatrix } from './components/CompetencyMatrix';
import { ExecutiveSummaryView } from './components/ExecutiveSummaryView';
import { CandidateDossierModal } from './components/CandidateDossierModal';
import { InterviewKitRunner } from './components/InterviewKitRunner';
import { ExportModal } from './components/ExportModal';

import { 
  JobProfile, 
  ResumeInput, 
  CandidateEvaluation, 
  RankingReport 
} from './types';

import { 
  DEFAULT_BENCHMARK_JOB, 
  SAMPLE_RESUME_TEXTS, 
  INITIAL_BENCHMARK_REPORT 
} from './data/sampleData';

export function App() {
  // Navigation & View State
  const [activeTab, setActiveTab] = useState<'leaderboard' | 'job' | 'resumes' | 'matrix' | 'briefing'>('leaderboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  
  // Core Data States
  const [jobProfile, setJobProfile] = useState<JobProfile>(DEFAULT_BENCHMARK_JOB);
  const [resumes, setResumes] = useState<ResumeInput[]>([
    {
      id: 'bench-elena',
      name: 'Elena Rostova',
      fileName: 'elena_rostova_staff_ai_lead.txt',
      content: SAMPLE_RESUME_TEXTS.elena_rostova,
      status: 'completed'
    },
    {
      id: 'bench-amina',
      name: 'Amina Al-Mansoor',
      fileName: 'amina_al_mansoor_senior_ai_biomed.txt',
      content: SAMPLE_RESUME_TEXTS.amina_al_mansoor,
      status: 'completed'
    },
    {
      id: 'bench-marcus',
      name: 'Marcus Chen',
      fileName: 'marcus_chen_lead_backend_infra.txt',
      content: SAMPLE_RESUME_TEXTS.marcus_chen,
      status: 'completed'
    },
    {
      id: 'bench-sarah',
      name: 'Sarah Jenkins',
      fileName: 'sarah_jenkins_frontend_ai_agency.txt',
      content: SAMPLE_RESUME_TEXTS.sarah_jenkins,
      status: 'completed'
    },
    {
      id: 'bench-david',
      name: 'David Miller',
      fileName: 'david_miller_enterprise_java_dev.txt',
      content: SAMPLE_RESUME_TEXTS.david_miller,
      status: 'completed'
    }
  ]);
  const [report, setReport] = useState<RankingReport | null>(INITIAL_BENCHMARK_REPORT);

  // Modals & Interactive Overlays
  const [selectedCandidate, setSelectedCandidate] = useState<CandidateEvaluation | null>(null);
  const [interviewCandidate, setInterviewCandidate] = useState<CandidateEvaluation | null>(null);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);

  // Processing & Evaluation State
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [evaluationProgress, setEvaluationProgress] = useState<{
    current: number;
    total: number;
    currentCandidateName?: string;
  }>({ current: 0, total: 0 });

  // Trigger Full AI Batch Evaluation Pipeline
  const handleRunBatchEvaluation = async () => {
    if (resumes.length === 0) return;
    setIsEvaluating(true);
    setEvaluationProgress({ current: 0, total: resumes.length, currentCandidateName: resumes[0]?.name });

    const evaluatedCandidates: CandidateEvaluation[] = [];
    const failures: { name: string; error: string }[] = [];

    // Mark every resume as evaluating up-front so the Ingest Resumes tab
    // reflects the run in progress even before each call resolves.
    setResumes((prev) => prev.map((r) => ({ ...r, status: 'evaluating', error: undefined })));

    // Evaluate sequentially (not Promise.all) to stay under Gemini rate
    // limits, but — critically — each resume gets its OWN try/catch. A
    // single failed/flaky resume used to throw out of the whole loop and
    // discard every already-completed evaluation. Now a failure is recorded
    // and the run continues, so partial results are never lost.
    for (let i = 0; i < resumes.length; i++) {
      const resume = resumes[i];
      setEvaluationProgress({
        current: i + 1,
        total: resumes.length,
        currentCandidateName: resume.name
      });

      try {
        const evalRes = await fetch('/api/evaluate-candidate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            jobProfile,
            resumeText: resume.content,
            candidateId: resume.id,
            candidateName: resume.name
          })
        });

        if (!evalRes.ok) {
          const errData = await evalRes.json().catch(() => ({}));
          throw new Error(errData.error || `Failed evaluating candidate: ${resume.name}`);
        }

        const candidateEval: CandidateEvaluation = await evalRes.json();
        evaluatedCandidates.push(candidateEval);
        setResumes((prev) => prev.map((r) => (r.id === resume.id ? { ...r, status: 'completed', error: undefined } : r)));
      } catch (err: any) {
        console.error(`Evaluation failed for ${resume.name}:`, err);
        const message = err.message || 'Evaluation failed for this candidate.';
        failures.push({ name: resume.name, error: message });
        setResumes((prev) => prev.map((r) => (r.id === resume.id ? { ...r, status: 'error', error: message } : r)));
      }
    }

    setIsEvaluating(false);

    if (evaluatedCandidates.length === 0) {
      alert(
        `All ${failures.length} candidate evaluation(s) failed. First error: ${failures[0]?.error || 'Unknown error'}. ` +
        `Check the server connection and GEMINI_API_KEY, then retry from the Ingest Resumes tab.`
      );
      return;
    }

    // Sort candidates by matchScore descending
    evaluatedCandidates.sort((a, b) => b.matchScore - a.matchScore);

    // Synthesize executive briefing
    let executiveBriefing = {
      topCandidateHighlights: `${evaluatedCandidates[0]?.name || 'Top Candidate'} ranked #1 with ${evaluatedCandidates[0]?.matchScore.toFixed(1) || 0}% match.`,
      marketFitAssessment: 'Applicant pool evaluated across multi-dimensional criteria.',
      hiringRisksAndTradeoffs: 'Review tradeoffs between candidates.',
      recommendedNextSteps: [
        `Advance ${evaluatedCandidates[0]?.name || 'top candidate'} to interview panel.`,
        'Send follow-ups to qualified candidates.'
      ]
    };

    try {
      const synthRes = await fetch('/api/synthesize-ranking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobProfile,
          candidates: evaluatedCandidates
        })
      });
      if (synthRes.ok) {
        executiveBriefing = await synthRes.json();
      }
    } catch (synthErr) {
      console.warn('Synthesis warning:', synthErr);
    }

    // Compute statistics
    const totalCandidates = evaluatedCandidates.length;
    const scores = evaluatedCandidates.map((c) => c.matchScore);
    const topScore = Math.max(...scores, 0);
    const averageScore = Number((scores.reduce((a, b) => a + b, 0) / (totalCandidates || 1)).toFixed(1));

    const tierCounts = {
      tier1: evaluatedCandidates.filter((c) => c.tier === 'TIER_1_TOP_SHORTLIST').length,
      tier2: evaluatedCandidates.filter((c) => c.tier === 'TIER_2_STRONG_CONTENDER').length,
      tier3: evaluatedCandidates.filter((c) => c.tier === 'TIER_3_HOLD_RESERVE').length,
      tier4: evaluatedCandidates.filter((c) => c.tier === 'TIER_4_DO_NOT_PROCEED').length
    };

    const newReport: RankingReport = {
      id: `report-${Date.now().toString(36)}`,
      jobProfile,
      evaluatedAt: new Date().toISOString(),
      candidates: evaluatedCandidates,
      executiveBriefing,
      statistics: {
        totalCandidates,
        averageScore,
        topScore,
        tierCounts
      }
    };

    setReport(newReport);

    // Celebrate completion
    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.6 }
    });

    // Switch to Leaderboard
    setActiveTab('leaderboard');

    if (failures.length > 0) {
      alert(
        `Evaluated ${evaluatedCandidates.length} of ${resumes.length} candidates successfully. ` +
        `${failures.length} failed and are marked in the Ingest Resumes tab: ` +
        failures.map((f) => f.name).join(', ')
      );
    }
  };

  // Load Benchmark Demo
  const handleLoadBenchmark = () => {
    setJobProfile(DEFAULT_BENCHMARK_JOB);
    setResumes([
      {
        id: 'bench-elena',
        name: 'Elena Rostova',
        fileName: 'elena_rostova_staff_ai_lead.txt',
        content: SAMPLE_RESUME_TEXTS.elena_rostova,
        status: 'completed'
      },
      {
        id: 'bench-amina',
        name: 'Amina Al-Mansoor',
        fileName: 'amina_al_mansoor_senior_ai_biomed.txt',
        content: SAMPLE_RESUME_TEXTS.amina_al_mansoor,
        status: 'completed'
      },
      {
        id: 'bench-marcus',
        name: 'Marcus Chen',
        fileName: 'marcus_chen_lead_backend_infra.txt',
        content: SAMPLE_RESUME_TEXTS.marcus_chen,
        status: 'completed'
      },
      {
        id: 'bench-sarah',
        name: 'Sarah Jenkins',
        fileName: 'sarah_jenkins_frontend_ai_agency.txt',
        content: SAMPLE_RESUME_TEXTS.sarah_jenkins,
        status: 'completed'
      },
      {
        id: 'bench-david',
        name: 'David Miller',
        fileName: 'david_miller_enterprise_java_dev.txt',
        content: SAMPLE_RESUME_TEXTS.david_miller,
        status: 'completed'
      }
    ]);
    setReport(INITIAL_BENCHMARK_REPORT);
    setActiveTab('leaderboard');

    confetti({
      particleCount: 50,
      spread: 50,
      origin: { y: 0.7 }
    });
  };

  // Reset to clean workspace
  const handleReset = () => {
    if (window.confirm('Reset the workspace? This will clear active candidate evaluations.')) {
      setResumes([]);
      setReport(null);
      setActiveTab('job');
    }
  };

  const candidateCount = report?.candidates.length || 0;

  return (
    <div className="flex h-screen w-screen bg-[#F1F5F9] font-sans text-[#1E293B] overflow-hidden">
      {/* Mobile Drawer Overlay */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 z-40 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar Navigation - Professional Polish Dark Navy #0F172A */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50 w-64 bg-[#0F172A] text-white flex flex-col shrink-0 transition-transform duration-200 ease-in-out
        ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Brand Logo Header */}
        <div className="p-6 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-xs">
              T
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-white block leading-tight">TalentRank AI</span>
              <span className="text-[10px] text-slate-400 font-medium">Enterprise Candidate Suite</span>
            </div>
          </div>
          <button 
            className="lg:hidden text-slate-400 hover:text-white"
            onClick={() => setMobileMenuOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Section */}
        <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
          <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Recruitment
          </div>

          <button
            id="nav-leaderboard"
            onClick={() => { setActiveTab('leaderboard'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'leaderboard'
                ? 'bg-blue-600 text-white shadow-xs font-semibold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <div className="flex items-center gap-3">
              <CheckCircle2 className={`w-4 h-4 ${activeTab === 'leaderboard' ? 'text-white' : 'text-slate-400'}`} />
              <span>Active Rankings</span>
            </div>
            {candidateCount > 0 && (
              <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                activeTab === 'leaderboard' ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-300'
              }`}>
                {candidateCount}
              </span>
            )}
          </button>

          <button
            id="nav-job-spec"
            onClick={() => { setActiveTab('job'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'job'
                ? 'bg-blue-600 text-white shadow-xs font-semibold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Sliders className={`w-4 h-4 ${activeTab === 'job' ? 'text-white' : 'text-slate-400'}`} />
            <span>Job Analysis</span>
          </button>

          <button
            id="nav-resumes-ingestion"
            onClick={() => { setActiveTab('resumes'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'resumes'
                ? 'bg-blue-600 text-white shadow-xs font-semibold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <div className="flex items-center gap-3">
              <Users className={`w-4 h-4 ${activeTab === 'resumes' ? 'text-white' : 'text-slate-400'}`} />
              <span>Ingest Resumes</span>
            </div>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-bold">
              {resumes.length}
            </span>
          </button>

          <button
            id="nav-matrix-view"
            onClick={() => { setActiveTab('matrix'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'matrix'
                ? 'bg-blue-600 text-white shadow-xs font-semibold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Layers className={`w-4 h-4 ${activeTab === 'matrix' ? 'text-white' : 'text-slate-400'}`} />
            <span>Rubric Templates</span>
          </button>

          <button
            id="nav-briefing-view"
            onClick={() => { setActiveTab('briefing'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'briefing'
                ? 'bg-blue-600 text-white shadow-xs font-semibold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <FileText className={`w-4 h-4 ${activeTab === 'briefing' ? 'text-white' : 'text-slate-400'}`} />
            <span>Executive Briefing</span>
          </button>

          <div className="pt-4 pb-1">
            <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Actions
            </div>
          </div>

          <button
            onClick={handleLoadBenchmark}
            disabled={isEvaluating}
            className="w-full flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-md text-sm font-medium transition-colors disabled:opacity-50 text-left"
          >
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span>Load Benchmark Data</span>
          </button>

          <button
            onClick={handleReset}
            className="w-full flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-rose-300 hover:bg-slate-800/60 rounded-md text-sm font-medium transition-colors text-left"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Workspace</span>
          </button>
        </nav>

        {/* Sidebar Footer User Info */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/40">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center font-bold text-xs text-slate-300 border border-slate-600">
              RA
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-white truncate">Recruiter Admin</p>
              <p className="text-[10px] text-slate-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                Gemini 3.7 Pro
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Workspace Area */}
      <main className="flex-1 flex flex-col overflow-hidden min-w-0 bg-[#F1F5F9]">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200 px-6 sm:px-8 flex items-center justify-between shrink-0 z-10 shadow-2xs">
          <div className="flex items-center gap-3 min-w-0">
            <button 
              className="lg:hidden p-1.5 rounded-md text-slate-600 hover:bg-slate-100"
              onClick={() => setMobileMenuOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold text-slate-800 truncate">
                Pipeline: {jobProfile.title}
              </h1>
              <p className="text-xs text-slate-500 italic truncate hidden sm:block">
                Evaluated against: {jobProfile.department || 'Technical Track'} • {jobProfile.seniorityLevel} (Internal ID: #{jobProfile.id.toUpperCase()})
              </p>
            </div>
          </div>

          {/* Header Action Buttons */}
          <div className="flex items-center gap-3 shrink-0">
            {report && (
              <button
                id="header-btn-export"
                onClick={() => setIsExportOpen(true)}
                className="px-4 py-1.5 border border-slate-300 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-slate-600" />
                <span className="hidden sm:inline">Export Report</span>
                <span className="sm:hidden">Export</span>
              </button>
            )}

            {activeTab === 'resumes' ? (
              <button
                onClick={handleRunBatchEvaluation}
                disabled={isEvaluating || resumes.length === 0}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-medium transition-colors shadow-2xs flex items-center gap-1.5 disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isEvaluating ? 'Evaluating...' : `Score ${resumes.length} Resumes`}</span>
              </button>
            ) : (
              <button
                onClick={() => setActiveTab('matrix')}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-medium transition-colors shadow-2xs flex items-center gap-1.5"
              >
                <Layers className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Compare Selected</span>
                <span className="sm:hidden">Compare</span>
              </button>
            )}
          </div>
        </header>

        {/* Dynamic Main Body Content */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6">
          {/* TAB 1: ACTIVE RANKINGS / LEADERBOARD */}
          {activeTab === 'leaderboard' && (
            report ? (
              <Leaderboard
                report={report}
                onSelectCandidate={(c) => setSelectedCandidate(c)}
                onOpenInterviewKit={(c) => setInterviewCandidate(c)}
                onOpenOutreachEmail={(c) => setSelectedCandidate(c)}
              />
            ) : (
              <div className="bg-white rounded-xl p-12 text-center text-slate-500 border border-slate-200 space-y-4 shadow-xs">
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-slate-900">No Active Candidate Rankings</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Ingest candidate resumes and run the AI ranking engine to generate scorecards, leaderboard metrics, and interview kits.
                </p>
                <div className="flex justify-center space-x-3 pt-2">
                  <button
                    onClick={handleLoadBenchmark}
                    className="px-4 py-2 rounded-md text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors shadow-xs"
                  >
                    Load Benchmark Demo
                  </button>
                  <button
                    onClick={() => setActiveTab('resumes')}
                    className="px-4 py-2 rounded-md text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors border border-slate-200"
                  >
                    Ingest Resumes
                  </button>
                </div>
              </div>
            )
          )}

          {/* TAB 2: JOB ANALYSIS & RUBRIC */}
          {activeTab === 'job' && (
            <JobProfileEditor
              jobProfile={jobProfile}
              setJobProfile={setJobProfile}
              onProceedToResumes={() => setActiveTab('resumes')}
            />
          )}

          {/* TAB 3: INGEST RESUMES */}
          {activeTab === 'resumes' && (
            <ResumeIngestion
              resumes={resumes}
              setResumes={setResumes}
              jobProfile={jobProfile}
              onRunBatchEvaluation={handleRunBatchEvaluation}
              isEvaluating={isEvaluating}
              evaluationProgress={evaluationProgress}
            />
          )}

          {/* TAB 4: RUBRIC TEMPLATES / COMPETENCY MATRIX */}
          {activeTab === 'matrix' && (
            report ? (
              <CompetencyMatrix
                report={report}
                onSelectCandidate={(c) => setSelectedCandidate(c)}
              />
            ) : (
              <div className="bg-white rounded-xl p-12 text-center text-slate-500 border border-slate-200 shadow-xs">
                <p className="text-sm font-semibold">Please run an evaluation first to view the comparison matrix.</p>
              </div>
            )
          )}

          {/* TAB 5: EXECUTIVE BRIEFING */}
          {activeTab === 'briefing' && (
            report ? (
              <ExecutiveSummaryView
                report={report}
                onSelectCandidate={(c) => setSelectedCandidate(c)}
              />
            ) : (
              <div className="bg-white rounded-xl p-12 text-center text-slate-500 border border-slate-200 shadow-xs">
                <p className="text-sm font-semibold">Please run an evaluation first to view the executive briefing.</p>
              </div>
            )
          )}
        </div>
      </main>

      {/* Candidate Dossier Modal */}
      {selectedCandidate && (
        <CandidateDossierModal
          candidate={selectedCandidate}
          onClose={() => setSelectedCandidate(null)}
          onOpenInterviewKit={(c) => {
            setSelectedCandidate(null);
            setInterviewCandidate(c);
          }}
        />
      )}

      {/* Live Phone Screen Interview Kit Runner */}
      {interviewCandidate && (
        <InterviewKitRunner
          candidate={interviewCandidate}
          onClose={() => setInterviewCandidate(null)}
        />
      )}

      {/* Export Report Modal */}
      {isExportOpen && (
        <ExportModal
          report={report}
          onClose={() => setIsExportOpen(false)}
        />
      )}
    </div>
  );
}

export default App;
