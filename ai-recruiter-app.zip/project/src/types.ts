export type DimensionCategory = 
  | 'technicalSkills'
  | 'experienceSeniority'
  | 'domainIndustryFit'
  | 'softSkillsLeadership'
  | 'educationCertifications';

export interface ScoringWeights {
  technicalSkills: number;
  experienceSeniority: number;
  domainIndustryFit: number;
  softSkillsLeadership: number;
  educationCertifications: number;
}

export interface JobProfile {
  id: string;
  title: string;
  company: string;
  department: string;
  location: string;
  employmentType: string;
  seniorityLevel: string;
  experienceRequiredYears: number;
  summary: string;
  mustHaveRequirements: string[];
  niceToHaveRequirements: string[];
  keyResponsibilities: string[];
  coreTechStack: string[];
  scoringWeights: ScoringWeights;
}

export interface MustHaveCheck {
  requirement: string;
  status: 'MET' | 'PARTIAL' | 'NOT_MET';
  evidence: string;
}

export interface DimensionScore {
  category: DimensionCategory;
  score: number; // 0 to 100
  weight: number; // 0 to 1
  weightedScore: number;
  rationale: string;
  evidenceFound: string[];
  missingOrWeak: string[];
}

export interface InterviewProbe {
  id: string;
  category: string;
  question: string;
  intent: string;
  positiveSignals: string[];
  redFlagSignals: string[];
  difficulty: 'Standard' | 'Challenging' | 'Deep Dive';
  recruiterNotes?: string;
  score?: number; // 1-5 rating during mock/live interview
}

export type RankingTier = 
  | 'TIER_1_TOP_SHORTLIST'
  | 'TIER_2_STRONG_CONTENDER'
  | 'TIER_3_HOLD_RESERVE'
  | 'TIER_4_DO_NOT_PROCEED';

export type RecommendationVerdict = 
  | 'Strong Hire'
  | 'Hire'
  | 'Leaning Hire'
  | 'Hold / Re-evaluate'
  | 'Reject';

export interface CandidateEvaluation {
  id: string;
  name: string;
  email: string;
  phone?: string;
  currentRole: string;
  currentCompany?: string;
  totalExperienceYears: number;
  matchScore: number; // 0 - 100
  tier: RankingTier;
  recommendationVerdict: RecommendationVerdict;
  keyVerdictHeadline: string;
  executiveSummary: string;
  mustHaveChecks: MustHaveCheck[];
  dimensions: {
    technicalSkills: DimensionScore;
    experienceSeniority: DimensionScore;
    domainIndustryFit: DimensionScore;
    softSkillsLeadership: DimensionScore;
    educationCertifications: DimensionScore;
  };
  keyStrengths: string[];
  criticalGaps: string[];
  riskFactors: string[];
  interviewKit: InterviewProbe[];
  communications: {
    outreachEmail: {
      subject: string;
      body: string;
    };
    rejectionEmail: {
      subject: string;
      body: string;
    };
    recruiterNotes: string;
  };
  rawResumeText: string;
  evaluatedAt: string;
}

export interface ExecutiveBriefing {
  topCandidateHighlights: string;
  marketFitAssessment: string;
  hiringRisksAndTradeoffs: string;
  recommendedNextSteps: string[];
}

export interface RankingReport {
  id: string;
  jobProfile: JobProfile;
  evaluatedAt: string;
  candidates: CandidateEvaluation[];
  executiveBriefing: ExecutiveBriefing;
  statistics: {
    totalCandidates: number;
    averageScore: number;
    topScore: number;
    tierCounts: {
      tier1: number;
      tier2: number;
      tier3: number;
      tier4: number;
    };
  };
}

export interface ResumeInput {
  id: string;
  name: string;
  fileName?: string;
  content: string;
  // 'parsing': file is being extracted server-side (PDF/DOCX upload in flight)
  // 'idle': parsed/pasted and ready for evaluation
  // 'evaluating': the batch evaluation run is currently scoring this resume
  // 'completed' / 'error': evaluation finished, with `error` set on failure
  status?: 'parsing' | 'idle' | 'evaluating' | 'completed' | 'error';
  error?: string;
}
