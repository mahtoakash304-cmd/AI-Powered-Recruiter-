import { JobProfile, CandidateEvaluation, RankingReport, ResumeInput } from '../types';

export const SAMPLE_JOB_PROFILES: JobProfile[] = [
  {
    id: 'job-ai-eng-01',
    title: 'Senior Full-Stack AI Engineer (Tech Lead Track)',
    company: 'NexusAI Technologies',
    department: 'Core Intelligent Systems',
    location: 'San Francisco, CA / Remote',
    employmentType: 'Full-time',
    seniorityLevel: 'Senior / Staff (5+ Years)',
    experienceRequiredYears: 5,
    summary: 'We are seeking a senior full-stack AI engineer to architect and build production-scale Generative AI applications, RAG pipelines, and intuitive user interfaces. You will lead technical design, mentor engineers, and bridge modern AI model capabilities with enterprise-grade web experiences.',
    mustHaveRequirements: [
      '5+ years of software engineering experience with strong proficiency in Python and TypeScript',
      'Hands-on experience architecting production RAG (Retrieval-Augmented Generation) systems with vector databases (e.g. Pinecone, Qdrant, Weaviate)',
      'Expertise in modern frontend frameworks (React, Next.js 14+, Tailwind CSS)',
      'Proven backend API development experience with FastAPI, Express, or Django with async processing',
      'Demonstrated technical leadership or mentoring experience on complex multi-tier projects'
    ],
    niceToHaveRequirements: [
      'Experience deploying models on Kubernetes, Docker, and AWS / GCP infrastructure',
      'Deep understanding of LLM evaluation benchmarks (Ragas, TruLens, G-Eval) and prompt caching',
      'Familiarity with agentic workflows (LangChain, LangGraph, AutoGen, CrewAI)',
      'B.S. or M.S. in Computer Science or related STEM discipline'
    ],
    keyResponsibilities: [
      'Architect, develop, and scale end-to-end full-stack AI applications with high reliability and sub-second latencies',
      'Design low-latency hybrid retrieval systems combining dense vector search and sparse lexical search',
      'Collaborate closely with product and design teams to create delightful, responsive AI interactive experiences',
      'Establish engineering best practices for testing, CI/CD, observability, and LLM output guardrails'
    ],
    coreTechStack: ['TypeScript', 'React / Next.js 14', 'Python', 'FastAPI', 'Qdrant / Pinecone', 'Gemini / OpenAI API', 'Docker', 'PostgreSQL', 'Tailwind CSS'],
    scoringWeights: {
      technicalSkills: 0.35,
      experienceSeniority: 0.25,
      domainIndustryFit: 0.20,
      softSkillsLeadership: 0.12,
      educationCertifications: 0.08
    }
  },
  {
    id: 'job-pm-02',
    title: 'Lead AI Product Manager',
    company: 'Synapse Enterprise',
    department: 'Enterprise AI Products',
    location: 'New York, NY / Hybrid',
    employmentType: 'Full-time',
    seniorityLevel: 'Lead / Principal (6+ Years)',
    experienceRequiredYears: 6,
    summary: 'Lead the vision, strategy, and execution of enterprise AI copilot products for Fortune 500 workflows. Partner with ML research and engineering to deliver high-impact automated intelligence.',
    mustHaveRequirements: [
      '6+ years of product management experience in B2B SaaS or enterprise software',
      'Proven track record shipping commercially successful AI / ML features to enterprise customers',
      'Strong technical fluency with LLMs, retrieval systems, and API design',
      'Demonstrated ability to synthesize customer discovery interviews into crisp PRDs and roadmaps'
    ],
    niceToHaveRequirements: [
      'Experience with AI safety, compliance, SOC2, and data privacy regulations',
      'Technical background with prior hands-on software development or data science experience',
      'MBA or Master\'s degree in relevant discipline'
    ],
    keyResponsibilities: [
      'Define multi-quarter product vision and prioritize feature roadmaps based on customer ROI',
      'Coordinate cross-functional go-to-market launches across sales, marketing, and customer success',
      'Establish KPI tracking for active user engagement, retention, and AI inference cost efficiency'
    ],
    coreTechStack: ['Jira', 'Figma', 'Mixpanel / Amplitude', 'SQL', 'LLM Prompt Engineering', 'Notion'],
    scoringWeights: {
      technicalSkills: 0.20,
      experienceSeniority: 0.25,
      domainIndustryFit: 0.30,
      softSkillsLeadership: 0.20,
      educationCertifications: 0.05
    }
  },
  {
    id: 'job-devops-03',
    title: 'Principal Cloud & DevOps Infrastructure Architect',
    company: 'CloudScale Global',
    department: 'Infrastructure & Reliability',
    location: 'Austin, TX / Remote',
    employmentType: 'Full-time',
    seniorityLevel: 'Principal (8+ Years)',
    experienceRequiredYears: 8,
    summary: 'Architect resilient multi-cloud Kubernetes infrastructure, automated GitOps deployment pipelines, and zero-trust security postures for high-throughput global platforms.',
    mustHaveRequirements: [
      '8+ years in DevOps, Cloud Architecture, or Site Reliability Engineering',
      'Deep mastery of Kubernetes cluster administration (EKS/GKE), Helm, and Service Meshes (Istio)',
      'Expertise in Infrastructure as Code (Terraform, Terragrunt, Pulumi)',
      'Track record designing 99.99% SLA multi-region disaster recovery architectures',
      'Experience mentoring senior engineers and leading architectural governance'
    ],
    niceToHaveRequirements: [
      'Experience optimizing GPU cluster workloads for distributed model training and inference',
      'FinOps cloud cost optimization certifications (AWS / GCP Solutions Architect Professional)',
      'Experience with eBPF, Cilium, Prometheus, and Grafana Loki telemetry stacks'
    ],
    keyResponsibilities: [
      'Define global cloud architecture and automate multi-tenant Kubernetes lifecycle management',
      'Maintain SOC2 Type II, ISO 27001, and HIPAA infrastructure compliance controls',
      'Lead incident post-mortems and drive systemic resilience improvements'
    ],
    coreTechStack: ['Kubernetes', 'Terraform', 'AWS / GCP', 'ArgoCD', 'Prometheus / Grafana', 'Python / Go', 'Docker'],
    scoringWeights: {
      technicalSkills: 0.40,
      experienceSeniority: 0.25,
      domainIndustryFit: 0.15,
      softSkillsLeadership: 0.15,
      educationCertifications: 0.05
    }
  }
];

export const SAMPLE_RESUME_TEXTS: Record<string, string> = {
  elena_rostova: `ELENA ROSTOVA
San Francisco, CA | elena.rostova@techmail.io | (415) 890-4321 | linkedin.com/in/elenarostova | github.com/erostova

EXECUTIVE SUMMARY
Staff / Senior Full-Stack AI Engineer with 7.5 years of experience architecting production Generative AI systems, hybrid RAG pipelines, and high-performance web applications. Tech Lead for a team of 6 engineers delivering enterprise AI copilots handling 12M+ monthly queries at sub-200ms latency.

EXPERIENCE
Aether AI Labs — San Francisco, CA
Staff AI Full-Stack Engineer (Tech Lead) | 2022 – Present
• Architected and scaled an enterprise RAG knowledge engine using FastAPI, Qdrant vector database, and Gemini/OpenAI models, achieving 99.94% availability for 45 enterprise clients.
• Designed the complete frontend client suite using Next.js 14 (App Router), TypeScript, Tailwind CSS, and WebSockets for real-time token streaming and interactive canvas visualization.
• Implemented hybrid search (dense embeddings + BM25 sparse retrieval) and re-ranking pipelines, reducing retrieval hallucination rates by 38% and lowering average latency from 450ms to 180ms.
• Mentored 6 full-stack engineers, initiated bi-weekly architecture reviews, and instituted automated evaluation harnesses using Ragas and pytest.
• Built containerized CI/CD microservices with Docker, Kubernetes (EKS), and GitHub Actions.

Vortex Systems — Palo Alto, CA
Senior Full-Stack Engineer | 2019 – 2022
• Engineered distributed REST & GraphQL APIs in Python (FastAPI/Django) and Node.js with PostgreSQL and Redis caching.
• Built high-density analytical dashboards in React, TypeScript, and D3.js utilized by over 80,000 daily active enterprise users.
• Spearheaded migration of legacy monolith to containerized microservices, reducing deployment downtime by 85%.

Kinetix Solutions — Austin, TX
Full-Stack Software Engineer | 2017 – 2019
• Developed responsive user interfaces in React/Redux and backend services in Python (Flask) and PostgreSQL.
• Collaborated with UX designers to build design system components adhering strictly to WCAG 2.1 AA accessibility standards.

SKILLS
• Languages: Python, TypeScript, JavaScript, SQL, Bash
• Frameworks: Next.js 14, React, FastAPI, Node.js, Express, Tailwind CSS, Django
• AI/ML & Data: RAG Architecture, Qdrant, Pinecone, LangChain, LlamaIndex, Vector Search, LLM Evaluation (Ragas), Embeddings
• Infrastructure: Docker, Kubernetes, AWS (EKS, S3, RDS), GCP, CI/CD, Redis, PostgreSQL, Git

EDUCATION
• M.S. in Computer Science (Artificial Intelligence Specialization) — Stanford University (2017)
• B.S. in Computer Science — UC Berkeley (2015, Magna Cum Laude)`,

  amina_al_mansoor: `AMINA AL-MANSOOR
Boston, MA | amina.almansoor@biomedai.net | (617) 555-0198 | linkedin.com/in/amina-almansoor

EXECUTIVE SUMMARY
Senior Full-Stack AI Engineer with 6 years of experience building specialized medical & clinical trial RAG systems, secure FastAPI backends, and responsive React/TypeScript user interfaces. Proven track record in high-security, compliance-driven AI deployment.

EXPERIENCE
Veritas Health Intelligence — Cambridge, MA
Senior Full-Stack AI Engineer | 2021 – Present
• Architected a HIPAA-compliant clinical trial matching system using FastAPI, TypeScript, Qdrant vector database, and customized LLM reasoning pipelines.
• Developed modern clinician dashboard using React 18, TypeScript, Vite, Tailwind CSS, and TanStack Query, enabling doctors to review patient-protocol alignments 4x faster.
• Created automated ingestion pipelines processing 2M+ biomedical PDFs and clinical trial documents with chunking, semantic deduplication, and hybrid vector indexing.
• Led sprint planning and code reviews for a pod of 4 engineers; authored comprehensive architectural specifications.

Beacon Data Systems — Boston, MA
Full-Stack Software Engineer | 2018 – 2021
• Built real-time telemetry ingestion services in Python and TypeScript connecting hospital IoT devices to AWS cloud databases.
• Developed customer-facing React web applications with robust state management and automated Cypress testing suites.
• Integrated PostgreSQL relational databases and optimized complex relational queries for 50M+ records.

SKILLS
• Core: Python, TypeScript, React, Next.js, FastAPI, Node.js, Tailwind CSS
• AI & Vector DBs: RAG, Qdrant, Pinecone, Embeddings, Semantic Search, Prompt Engineering
• Cloud & Tools: AWS, Docker, Kubernetes, PostgreSQL, Git, Redis, Jest, Playwright

EDUCATION
• B.S. in Computer Science & Biological Sciences — MIT (2018)`,

  marcus_chen: `MARCUS CHEN
Seattle, WA | marcus.chen.infra@devmail.org | (206) 432-9012 | github.com/marcuschen-sys

EXECUTIVE SUMMARY
Lead Distributed Backend & Infrastructure Engineer with 9 years of experience building high-throughput distributed systems, low-latency microservices, and large-scale data ingestion engines in Python, Go, and C++.

EXPERIENCE
HyperScale Distributed Systems — Seattle, WA
Lead Backend Engineer | 2020 – Present
• Designed distributed streaming pipeline handling 400,000 events/sec using Kafka, Python, Go, and Redis clusters.
• Architected and deployed microservices backend in Python (FastAPI/gRPC) across multi-region Kubernetes clusters on AWS.
• Implemented early vector indexing service using Faiss and C++ bindings for fast similarity searches.
• Mentored 8 junior and mid-level backend developers across global engineering hubs.

Amazon Web Services — Seattle, WA
Senior Systems Engineer | 2017 – 2020
• Built internal orchestration services for EC2 infrastructure provisioning with 99.999% reliability targets.
• Authored Python automation tools reducing hardware diagnostic cycles by 60%.

Pacific Cloud Labs — Portland, OR
Backend Software Developer | 2015 – 2017
• Built RESTful APIs in Python (Django) and managed PostgreSQL database partitions.

SKILLS & LIMITATIONS
• Strengths: Python, Go, C++, Distributed Systems, Kubernetes, Kafka, AWS, Docker, Linux, System Architecture
• Familiarity: Basic HTML/CSS, minimal client-side JavaScript, very limited modern React/Next.js/TypeScript frontend experience

EDUCATION
• B.S. in Computer Engineering — University of Washington (2015)`,

  sarah_jenkins: `SARAH JENKINS
Chicago, IL | sarah.jenkins@designcode.io | (312) 887-2341 | sarahjenkins.dev

EXECUTIVE SUMMARY
Creative Full-Stack Developer with 3.5 years of experience building polished, interactive web applications using React, Next.js, TypeScript, and modern CSS/Tailwind. Passionate about UI/UX craft and integrating AI APIs for consumer applications.

EXPERIENCE
PixelCraft Digital — Chicago, IL
Full-Stack Developer | 2022 – Present
• Developed interactive web applications for 15+ agency clients using Next.js 13/14, React, TypeScript, and Tailwind CSS.
• Integrated OpenAI and Gemini API endpoints into client websites for copy generation and AI chatbots using lightweight Express wrappers.
• Built responsive animations and custom user interfaces with Framer Motion and Lucide icons.
• Improved frontend web vitals across client portfolio, achieving consistent 95+ Google PageSpeed scores.

Lumina Creative Agency — Chicago, IL
Junior Frontend Developer | 2021 – 2022
• Built landing pages and marketing sites using React, HTML5, CSS3, and JavaScript (ES6+).
• Maintained automated cross-browser testing suites and resolved accessibility tickets.

SKILLS
• Languages & Frontend: TypeScript, JavaScript, React, Next.js, HTML5, CSS3, Tailwind CSS, Framer Motion
• Backend & AI: Node.js, Express, Basic Python (Flask), OpenAI API integration, Supabase, PostgreSQL
• Tools: Figma, Git, Vercel, Vite, npm

EDUCATION
• B.A. in Interactive Media & Web Design — DePaul University (2021)`,

  david_miller: `DAVID MILLER
Dallas, TX | david.miller.enterprise@corpmail.com | (214) 765-4321

EXECUTIVE SUMMARY
Senior Enterprise Software Developer with 10 years of experience designing and maintaining mission-critical enterprise ERP and CRM systems in Java, Spring Boot, Oracle Database, and enterprise SOA environments.

EXPERIENCE
Titan Financial Solutions — Dallas, TX
Senior Enterprise Java Developer | 2018 – Present
• Designed and maintained high-security banking transaction gateways processing $500M+ in daily settlement transactions using Java 8/11, Spring Boot, and Apache Camel.
• Managed and optimized relational schemas and PL/SQL stored procedures on enterprise Oracle 19c clusters.
• Ensured compliance with PCI-DSS financial regulatory audits and banking security protocols.

Global Logistics Systems — Fort Worth, TX
Enterprise Software Engineer | 2014 – 2018
• Developed backend enterprise services in Java EE, SOAP web services, and IBM WebSphere.
• Maintained legacy relational databases and batch ETL processing scripts.

SKILLS
• Enterprise Languages: Java 8/11/17, Spring Boot, Hibernate, SQL, PL/SQL, Bash
• Databases: Oracle Database, Microsoft SQL Server, DB2
• Technologies: Maven, Jenkins, SOAP/REST APIs, JUnit, Linux Enterprise Server
• Note: No commercial experience with Python, TypeScript, modern React/Next.js frameworks, or Generative AI/RAG architectures.

EDUCATION
• B.S. in Information Technology — University of Texas at Dallas (2014)`
};

export const DEFAULT_BENCHMARK_JOB: JobProfile = SAMPLE_JOB_PROFILES[0];

export const INITIAL_BENCHMARK_REPORT: RankingReport = {
  id: 'report-demo-01',
  jobProfile: SAMPLE_JOB_PROFILES[0],
  evaluatedAt: '2026-08-28T02:30:00.000Z',
  candidates: [
    {
      id: 'cand-01',
      name: 'Elena Rostova',
      email: 'elena.rostova@techmail.io',
      phone: '(415) 890-4321',
      currentRole: 'Staff AI Full-Stack Engineer (Tech Lead)',
      currentCompany: 'Aether AI Labs',
      totalExperienceYears: 7.5,
      matchScore: 95.9,
      tier: 'TIER_1_TOP_SHORTLIST',
      recommendationVerdict: 'Strong Hire',
      keyVerdictHeadline: 'Ideal dual-threat: 7.5 yrs exp, production RAG scale, Next.js 14, FastAPI, team lead',
      executiveSummary: 'Elena is an exceptional Staff-level candidate who directly fulfills every mandatory and nice-to-have requirement. She currently serves as Tech Lead for a team of 6, operating production RAG systems on Qdrant/FastAPI handling 12M+ monthly queries, paired with Next.js 14 App Router and streaming UI. Standout candidate with M.S. from Stanford.',
      mustHaveChecks: [
        {
          requirement: '5+ years software engineering experience in Python and TypeScript',
          status: 'MET',
          evidence: '7.5 years total experience with extensive commercial production work in both Python and TypeScript.'
        },
        {
          requirement: 'Production RAG systems with vector databases (Pinecone, Qdrant)',
          status: 'MET',
          evidence: 'Architected enterprise RAG on Qdrant + FastAPI with hybrid search (dense + BM25), cutting hallucination by 38%.'
        },
        {
          requirement: 'Expertise in modern frontend (React, Next.js 14+, Tailwind CSS)',
          status: 'MET',
          evidence: 'Built complete Next.js 14 (App Router) client suite with Tailwind CSS, WebSockets streaming, and interactive canvas.'
        },
        {
          requirement: 'Backend API development with FastAPI/Express and async processing',
          status: 'MET',
          evidence: 'Engineered high-throughput FastAPI and Node.js microservices with sub-200ms latencies and Redis caching.'
        },
        {
          requirement: 'Technical leadership or mentoring experience on complex projects',
          status: 'MET',
          evidence: 'Staff Tech Lead managing 6 engineers, architecture review boards, and Ragas automated testing harnesses.'
        }
      ],
      dimensions: {
        technicalSkills: {
          category: 'technicalSkills',
          score: 98.0,
          weight: 0.35,
          weightedScore: 34.3,
          rationale: 'World-class mastery of Next.js 14, FastAPI, Qdrant vector DB, and RAG evaluation frameworks.',
          evidenceFound: ['Next.js 14 App Router', 'Qdrant hybrid search', 'FastAPI async microservices', 'Ragas LLM evaluation', 'WebSockets streaming'],
          missingOrWeak: ['None observed']
        },
        experienceSeniority: {
          category: 'experienceSeniority',
          score: 95.0,
          weight: 0.25,
          weightedScore: 23.75,
          rationale: '7.5 years of continuous high-impact software engineering, advancing from engineer to Staff Tech Lead.',
          evidenceFound: ['Staff Engineer & Tech Lead', '7.5 years verified tenure', '12M+ monthly query scale'],
          missingOrWeak: []
        },
        domainIndustryFit: {
          category: 'domainIndustryFit',
          score: 98.0,
          weight: 0.20,
          weightedScore: 19.6,
          rationale: 'Direct subject-matter expertise in production enterprise AI copilots, latency optimization, and guardrails.',
          evidenceFound: ['Enterprise AI Labs experience', '38% hallucination reduction', 'Sub-200ms latency tuning'],
          missingOrWeak: []
        },
        softSkillsLeadership: {
          category: 'softSkillsLeadership',
          score: 90.0,
          weight: 0.12,
          weightedScore: 10.8,
          rationale: 'Demonstrated leadership of a 6-person engineering pod, running architecture reviews and mentoring.',
          evidenceFound: ['Mentored 6 engineers', 'Led cross-functional architecture reviews', 'Established test guidelines'],
          missingOrWeak: []
        },
        educationCertifications: {
          category: 'educationCertifications',
          score: 95.0,
          weight: 0.08,
          weightedScore: 7.6,
          rationale: 'M.S. in CS (AI Spec) from Stanford University + B.S. in CS from UC Berkeley (Magna Cum Laude).',
          evidenceFound: ['Stanford University M.S. CS (AI)', 'UC Berkeley B.S. CS Magna Cum Laude'],
          missingOrWeak: []
        }
      },
      keyStrengths: [
        'End-to-end full-stack AI mastery: from Next.js 14 UI streaming down to Qdrant vector search and FastAPI microservices',
        'Proven tech leadership: manages 6 engineers and enforces automated Ragas evaluation standards',
        'Proven scale: built enterprise systems handling 12M+ queries with 99.94% availability',
        'Prestigious academic background: Stanford M.S. (AI) and UC Berkeley B.S.'
      ],
      criticalGaps: [
        'Minimal gaps identified; evaluate culture fit and compensation alignment during offer stage'
      ],
      riskFactors: [
        'High market demand / potential competing offers from Tier 1 AI research labs'
      ],
      interviewKit: [
        {
          id: 'probe-1',
          category: 'RAG Architecture & Latency',
          question: 'In your enterprise RAG system at Aether AI Labs, how did you architect the hybrid retrieval pipeline between dense embeddings and BM25 to keep latency under 200ms?',
          intent: 'Verify hands-on vector database indexing, re-ranking compute overhead, and caching strategies.',
          positiveSignals: [
            'Mentions reciprocal rank fusion (RRF) or cross-encoder re-rankers with early-stopping heuristics',
            'Explains asynchronous pre-fetching and semantic caching using Redis',
            'Discusses trade-offs between embedding dimension reduction and recall accuracy'
          ],
          redFlagSignals: [
            'Generic textbook answers without real production trade-off anecdotes',
            'Inability to explain how re-ranking latency was budgeted within total SLA'
          ],
          difficulty: 'Deep Dive'
        },
        {
          id: 'probe-2',
          category: 'Frontend Streaming & UX',
          question: 'How did you handle UI state management and error boundary recovery when streaming tokens over WebSockets in Next.js 14 App Router?',
          intent: 'Assess frontend architecture depth and handling of network packet drops or LLM generation aborts.',
          positiveSignals: [
            'Uses React Server Components (RSC) with Suspense or custom ReadableStream readers',
            'Graceful retry logic and optimistic rendering during token streaming disconnects'
          ],
          redFlagSignals: [
            'Relying on basic polling or unhandled component memory leaks on stream disconnect'
          ],
          difficulty: 'Challenging'
        },
        {
          id: 'probe-3',
          category: 'Tech Leadership & Mentoring',
          question: 'Describe a time when your 6-engineer pod had a fundamental architectural disagreement regarding LLM guardrails or database schema. How did you guide consensus?',
          intent: 'Evaluate collaborative leadership style, technical RFC processes, and decision maturity.',
          positiveSignals: [
            'Mentions data-driven prototyping, RFC design docs, and clear tradeoff matrices',
            'Empowers team members while maintaining delivery accountability'
          ],
          redFlagSignals: [
            'Top-down autocratic decision making or avoiding difficult technical debates'
          ],
          difficulty: 'Standard'
        }
      ],
      communications: {
        outreachEmail: {
          subject: 'Leadership Opportunity: Senior Full-Stack AI Engineer @ NexusAI Technologies',
          body: `Hi Elena,\n\nI came across your impressive work leading the AI Full-Stack engineering team at Aether AI Labs and your track record scaling production RAG systems with Qdrant and Next.js 14.\n\nAt NexusAI Technologies, we are expanding our Core Intelligent Systems team and looking for a Senior / Staff AI Engineer on a Tech Lead track to architect our next-generation intelligent copilot platform.\n\nGiven your deep expertise across hybrid retrieval, streaming architectures, and team mentorship, I would love to connect for a quick 15-minute introductory conversation this week.\n\nBest regards,\nNexusAI Talent Acquisition Team`
        },
        rejectionEmail: {
          subject: 'Your Application at NexusAI Technologies',
          body: `Hi Elena,\n\nThank you for taking the time to speak with our engineering leadership team. While we were deeply impressed by your background, we are proceeding with other candidates whose profiles align more specifically with our immediate needs.`
        },
        recruiterNotes: 'Priority 1 candidate. Fast-track directly to Hiring Manager technical screen.'
      },
      rawResumeText: SAMPLE_RESUME_TEXTS.elena_rostova,
      evaluatedAt: '2026-08-28T02:30:00.000Z'
    },
    {
      id: 'cand-02',
      name: 'Amina Al-Mansoor',
      email: 'amina.almansoor@biomedai.net',
      phone: '(617) 555-0198',
      currentRole: 'Senior Full-Stack AI Engineer',
      currentCompany: 'Veritas Health Intelligence',
      totalExperienceYears: 6.0,
      matchScore: 90.8,
      tier: 'TIER_1_TOP_SHORTLIST',
      recommendationVerdict: 'Strong Hire',
      keyVerdictHeadline: '6 yrs exp, clinical trial RAG systems, Qdrant, TypeScript/FastAPI, strong candidate',
      executiveSummary: 'Amina brings 6 years of solid full-stack AI engineering with deep experience in compliance-driven RAG pipelines, Qdrant, React/TypeScript dashboards, and large-scale PDF ingestion (2M+ docs). Solid lead candidate with MIT B.S.',
      mustHaveChecks: [
        {
          requirement: '5+ years software engineering experience in Python and TypeScript',
          status: 'MET',
          evidence: '6 years verified full-stack experience across Python (FastAPI) and TypeScript/React.'
        },
        {
          requirement: 'Production RAG systems with vector databases (Pinecone, Qdrant)',
          status: 'MET',
          evidence: 'Built clinical trial RAG engine with Qdrant and 2M+ document ingestion pipelines.'
        },
        {
          requirement: 'Expertise in modern frontend (React, Next.js 14+, Tailwind CSS)',
          status: 'MET',
          evidence: 'Built clinician dashboards using React 18, TypeScript, Tailwind CSS, and TanStack Query.'
        },
        {
          requirement: 'Backend API development with FastAPI/Express and async processing',
          status: 'MET',
          evidence: 'Engineered HIPAA-compliant FastAPI backend services and telemetry pipelines.'
        },
        {
          requirement: 'Technical leadership or mentoring experience on complex projects',
          status: 'MET',
          evidence: 'Led sprint planning, architecture specs, and code reviews for a 4-engineer pod.'
        }
      ],
      dimensions: {
        technicalSkills: {
          category: 'technicalSkills',
          score: 92.0,
          weight: 0.35,
          weightedScore: 32.2,
          rationale: 'Strong proficiency in Python, FastAPI, Qdrant, React, and TypeScript with rigorous HIPAA compliance.',
          evidenceFound: ['FastAPI microservices', 'Qdrant vector indexing', 'React 18 & TypeScript', '2M+ PDF ingestion pipeline'],
          missingOrWeak: ['Next.js 14 specific experience not explicitly highlighted; primarily React 18 Vite SPA']
        },
        experienceSeniority: {
          category: 'experienceSeniority',
          score: 90.0,
          weight: 0.25,
          weightedScore: 22.5,
          rationale: '6 years of consistent software engineering experience in high-security domains.',
          evidenceFound: ['Senior Engineer role', '6 years continuous tenure'],
          missingOrWeak: []
        },
        domainIndustryFit: {
          category: 'domainIndustryFit',
          score: 95.0,
          weight: 0.20,
          weightedScore: 19.0,
          rationale: 'Excellent domain fit for enterprise AI, sensitive data management, and sub-second retrieval.',
          evidenceFound: ['Biomedical RAG applications', 'HIPAA compliance', 'Semantic deduplication'],
          missingOrWeak: []
        },
        softSkillsLeadership: {
          category: 'softSkillsLeadership',
          score: 85.0,
          weight: 0.12,
          weightedScore: 10.2,
          rationale: 'Pod lead for 4 engineers, driving sprint cadence and architectural documentation.',
          evidenceFound: ['Led 4-engineer pod', 'Authored technical specs'],
          missingOrWeak: []
        },
        educationCertifications: {
          category: 'educationCertifications',
          score: 90.0,
          weight: 0.08,
          weightedScore: 7.2,
          rationale: 'B.S. in Computer Science & Biological Sciences from MIT.',
          evidenceFound: ['MIT B.S. CS & Biology (2018)'],
          missingOrWeak: []
        }
      },
      keyStrengths: [
        'Robust experience handling high-volume unstructured document ingestion (2M+ PDFs) and semantic chunking',
        'Strong compliance and data privacy mindset (HIPAA/enterprise grade)',
        'Great track record of delivering clean React/TypeScript clinician interfaces',
        'Solid educational pedigree (MIT CS)'
      ],
      criticalGaps: [
        'Experience is primarily with React SPA rather than Next.js 14 Server Actions / App Router; quick ramp expected'
      ],
      riskFactors: [
        'Verify interest in moving from HealthTech into broader enterprise AI platform domain'
      ],
      interviewKit: [
        {
          id: 'probe-a1',
          category: 'Document Ingestion & Chunking',
          question: 'When ingesting 2M+ biomedical PDFs, how did you handle table extraction, multi-column layouts, and semantic chunking boundaries?',
          intent: 'Evaluate real-world data parsing challenges beyond standard character-count splitters.',
          positiveSignals: [
            'Discusses layout-aware parsers, OCR pipelines, and chunk overlap tuning',
            'Explains metadata tagging strategies for granular filtering'
          ],
          redFlagSignals: [
            'Simple naive regex splitters without handling edge cases or OCR artifacts'
          ],
          difficulty: 'Challenging'
        },
        {
          id: 'probe-a2',
          category: 'Next.js & SSR Transition',
          question: 'How would you compare client-side TanStack Query data fetching with Next.js 14 Server Components for streaming AI responses?',
          intent: 'Gauge adaptability to our specific frontend tech stack.',
          positiveSignals: [
            'Clearly articulates differences in TTFB, bundle size, and server caching strategies'
          ],
          redFlagSignals: [
            'Unfamiliar with server-side rendering concepts or streaming Suspense'
          ],
          difficulty: 'Standard'
        }
      ],
      communications: {
        outreachEmail: {
          subject: 'Senior AI Engineer Opportunity @ NexusAI Technologies',
          body: `Hi Amina,\n\nI came across your background building HIPAA-compliant RAG engines and complex React/TypeScript applications at Veritas Health Intelligence.\n\nWe are looking for a Senior Full-Stack AI Engineer to lead core application pipelines here at NexusAI Technologies. Your background in large-scale document ingestion and clean frontend engineering would make an immediate impact.\n\nLet me know if you have 15 minutes for a brief intro call.\n\nBest,\nNexusAI Recruiting Team`
        },
        rejectionEmail: {
          subject: 'NexusAI Technologies - Application Update',
          body: `Hi Amina,\n\nThank you for taking the time to interview with us. We appreciate your dedication and wish you the best in your continued success.`
        },
        recruiterNotes: 'Strong Tier 1 candidate. Schedule HM interview.'
      },
      rawResumeText: SAMPLE_RESUME_TEXTS.amina_al_mansoor,
      evaluatedAt: '2026-08-28T02:30:00.000Z'
    },
    {
      id: 'cand-03',
      name: 'Marcus Chen',
      email: 'marcus.chen.infra@devmail.org',
      phone: '(206) 432-9012',
      currentRole: 'Lead Backend Engineer',
      currentCompany: 'HyperScale Distributed Systems',
      totalExperienceYears: 9.0,
      matchScore: 69.5,
      tier: 'TIER_3_HOLD_RESERVE',
      recommendationVerdict: 'Leaning Hire',
      keyVerdictHeadline: 'Exceptional distributed backend & infra (9 yrs), but lacks modern React/TS frontend',
      executiveSummary: 'Marcus is a heavyweight distributed systems engineer with 9 years of experience in Python, Go, Kafka, and Kubernetes. While his backend and infrastructure capabilities far exceed the senior bar, he explicitly lacks modern frontend (React/Next.js/TypeScript) depth required for a full-stack dual-threat role.',
      mustHaveChecks: [
        {
          requirement: '5+ years software engineering experience in Python and TypeScript',
          status: 'PARTIAL',
          evidence: '9 years in Python, Go, and C++, but minimal commercial TypeScript.'
        },
        {
          requirement: 'Production RAG systems with vector databases (Pinecone, Qdrant)',
          status: 'PARTIAL',
          evidence: 'Built Faiss C++ similarity search services, but lacks full RAG generation pipeline experience.'
        },
        {
          requirement: 'Expertise in modern frontend (React, Next.js 14+, Tailwind CSS)',
          status: 'NOT_MET',
          evidence: 'Self-reported minimal JavaScript and no commercial React/Next.js frontend experience.'
        },
        {
          requirement: 'Backend API development with FastAPI/Express and async processing',
          status: 'MET',
          evidence: 'Deep mastery of FastAPI, gRPC, Redis, Kafka (400k events/sec), and distributed microservices.'
        },
        {
          requirement: 'Technical leadership or mentoring experience on complex projects',
          status: 'MET',
          evidence: 'Lead Engineer mentoring 8 backend developers across global hubs.'
        }
      ],
      dimensions: {
        technicalSkills: {
          category: 'technicalSkills',
          score: 55.0,
          weight: 0.35,
          weightedScore: 19.25,
          rationale: 'Phenomenal backend (95+) heavily offset by absence of modern React/TypeScript frontend (15).',
          evidenceFound: ['Kafka 400k events/sec', 'FastAPI / gRPC microservices', 'Faiss vector indexing', 'Kubernetes AWS'],
          missingOrWeak: ['No modern React / Next.js', 'No Tailwind CSS', 'Minimal TypeScript']
        },
        experienceSeniority: {
          category: 'experienceSeniority',
          score: 85.0,
          weight: 0.25,
          weightedScore: 21.25,
          rationale: '9 years of senior and lead engineering experience across top-tier distributed platforms.',
          evidenceFound: ['9 years experience', 'AWS EC2 systems', 'Lead Engineer role'],
          missingOrWeak: []
        },
        domainIndustryFit: {
          category: 'domainIndustryFit',
          score: 60.0,
          weight: 0.20,
          weightedScore: 12.0,
          rationale: 'Superb infrastructure fit, but partial fit for consumer/enterprise conversational UI applications.',
          evidenceFound: ['Distributed systems', 'Vector similarity search'],
          missingOrWeak: ['Full-stack AI app orchestration', 'Prompt engineering']
        },
        softSkillsLeadership: {
          category: 'softSkillsLeadership',
          score: 85.0,
          weight: 0.12,
          weightedScore: 10.2,
          rationale: 'Experienced team lead with 8 direct mentees.',
          evidenceFound: ['Mentored 8 engineers', 'Cross-timezone leadership'],
          missingOrWeak: []
        },
        educationCertifications: {
          category: 'educationCertifications',
          score: 90.0,
          weight: 0.08,
          weightedScore: 7.2,
          rationale: 'B.S. in Computer Engineering from University of Washington.',
          evidenceFound: ['Univ of Washington B.S. CompE'],
          missingOrWeak: []
        }
      },
      keyStrengths: [
        'Top 1% distributed systems architecture, concurrency, and high-throughput streaming (400k events/sec)',
        'Extensive Kubernetes, AWS, and bare-metal infrastructure mastery',
        'Proven technical lead with 9 years in industry'
      ],
      criticalGaps: [
        'No hands-on modern React or Next.js experience; cannot autonomously build full-stack interfaces without pairing'
      ],
      riskFactors: [
        'Candidate is better suited for a pure Principal Backend / AI Infra Engineer role rather than Full-Stack'
      ],
      interviewKit: [
        {
          id: 'probe-m1',
          category: 'Role Alignment & Frontend Willingness',
          question: 'This role requires building end-to-end user interfaces in Next.js 14 and TypeScript alongside backend APIs. How comfortable are you diving into modern React and CSS layout engineering?',
          intent: 'Determine if candidate is genuinely interested in full-stack work or exclusively backend.',
          positiveSignals: [
            'Eagerness to learn modern frontend paradigms; has completed side projects or experiments'
          ],
          redFlagSignals: [
            'Disdain for frontend work or expectation that UI will be delegated away completely'
          ],
          difficulty: 'Standard'
        }
      ],
      communications: {
        outreachEmail: {
          subject: 'Engineering Opportunities @ NexusAI Technologies',
          body: `Hi Marcus,\n\nWe saw your extensive background in distributed systems and high-throughput Python backends at HyperScale. While our current opening is specifically for a Full-Stack AI Engineer with heavy Next.js frontend requirements, we also have dedicated Backend Infrastructure roles where your expertise would be a stellar match.\n\nLet's connect if you're open to exploring backend infra positions.\n\nBest,\nNexusAI Talent Team`
        },
        rejectionEmail: {
          subject: 'Update on Full-Stack Role @ NexusAI',
          body: `Hi Marcus,\n\nThank you for your interest in our Full-Stack AI Engineer role. Due to our immediate need for heavy Next.js 14 frontend execution, we are holding your resume for our upcoming Backend Core Infra opening.`
        },
        recruiterNotes: 'Hold for pure backend / AI infrastructure role. Do not advance for Full-Stack role unless hiring pure backend.'
      },
      rawResumeText: SAMPLE_RESUME_TEXTS.marcus_chen,
      evaluatedAt: '2026-08-28T02:30:00.000Z'
    },
    {
      id: 'cand-04',
      name: 'Sarah Jenkins',
      email: 'sarah.jenkins@designcode.io',
      phone: '(312) 887-2341',
      currentRole: 'Full-Stack Developer',
      currentCompany: 'PixelCraft Digital',
      totalExperienceYears: 3.5,
      matchScore: 52.2,
      tier: 'TIER_4_DO_NOT_PROCEED',
      recommendationVerdict: 'Reject',
      keyVerdictHeadline: 'Great modern UI skills, but junior for senior lead bar (3.5 yrs total exp, light backend)',
      executiveSummary: 'Sarah is a talented, design-oriented web developer with great React/Next.js/Tailwind skills, but possesses only 3.5 years total experience (below 5-year senior requirement). Her backend and AI experience is limited to lightweight Express wrappers and basic API calls rather than production RAG or vector database architecture.',
      mustHaveChecks: [
        {
          requirement: '5+ years software engineering experience in Python and TypeScript',
          status: 'NOT_MET',
          evidence: '3.5 years total experience; primarily JavaScript/TypeScript with basic Python.'
        },
        {
          requirement: 'Production RAG systems with vector databases (Pinecone, Qdrant)',
          status: 'NOT_MET',
          evidence: 'Only basic OpenAI/Gemini API wrapper calls; no vector DB or RAG pipeline experience.'
        },
        {
          requirement: 'Expertise in modern frontend (React, Next.js 14+, Tailwind CSS)',
          status: 'MET',
          evidence: 'Strong proficiency in Next.js 13/14, Tailwind CSS, and Framer Motion animations.'
        },
        {
          requirement: 'Backend API development with FastAPI/Express and async processing',
          status: 'PARTIAL',
          evidence: 'Lightweight Express wrappers, basic Supabase, but lacks scalable microservice architecture.'
        },
        {
          requirement: 'Technical leadership or mentoring experience on complex projects',
          status: 'NOT_MET',
          evidence: 'Individual contributor at digital agency; no team leadership or mentoring demonstrated.'
        }
      ],
      dimensions: {
        technicalSkills: {
          category: 'technicalSkills',
          score: 55.0,
          weight: 0.35,
          weightedScore: 19.25,
          rationale: 'Excellent UI/Next.js design craft (85), but lacks production backend, RAG pipelines, and vector DBs (25).',
          evidenceFound: ['Next.js 13/14', 'Tailwind CSS', 'Framer Motion', 'OpenAI API client'],
          missingOrWeak: ['No vector database experience', 'No Python FastAPI in production', 'No distributed systems']
        },
        experienceSeniority: {
          category: 'experienceSeniority',
          score: 40.0,
          weight: 0.25,
          weightedScore: 10.0,
          rationale: '3.5 years of experience falls significantly short of the 5+ years Senior/Staff Tech Lead threshold.',
          evidenceFound: ['3.5 years total tenure'],
          missingOrWeak: ['Lacks senior-level tenure']
        },
        domainIndustryFit: {
          category: 'domainIndustryFit',
          score: 60.0,
          weight: 0.20,
          weightedScore: 12.0,
          rationale: 'Agency/marketing web dev background rather than deep AI systems engineering.',
          evidenceFound: ['Consumer web applications', 'Interactive animations'],
          missingOrWeak: ['Enterprise AI architectures']
        },
        softSkillsLeadership: {
          category: 'softSkillsLeadership',
          score: 50.0,
          weight: 0.12,
          weightedScore: 6.0,
          rationale: 'Individual contributor with no formal tech lead or mentoring responsibilities.',
          evidenceFound: [],
          missingOrWeak: ['No leadership experience demonstrated']
        },
        educationCertifications: {
          category: 'educationCertifications',
          score: 75.0,
          weight: 0.08,
          weightedScore: 6.0,
          rationale: 'B.A. in Interactive Media & Web Design from DePaul University.',
          evidenceFound: ['DePaul University B.A.'],
          missingOrWeak: ['Non-CS STEM degree']
        }
      },
      keyStrengths: [
        'High attention to frontend detail, web vitals, and micro-interactions',
        'Proficient in Next.js 14 and Tailwind CSS'
      ],
      criticalGaps: [
        'Total experience (3.5 yrs) is below Senior/Staff Tech Lead bar',
        'No production experience with RAG, vector databases (Qdrant/Pinecone), or complex Python backend microservices'
      ],
      riskFactors: [
        'Would struggle with architectural leadership and high-scale distributed backend engineering'
      ],
      interviewKit: [
        {
          id: 'probe-s1',
          category: 'Backend Architecture Depth',
          question: 'Describe the largest database or backend system you have designed from scratch. How did you handle caching, concurrency, and schema migrations?',
          intent: 'Verify if candidate has backend depth beyond basic CMS/Supabase scaffolding.',
          positiveSignals: ['Knowledge of indexing, database locks, and connection pooling'],
          redFlagSignals: ['Relies purely on third-party BaaS without understanding core principles'],
          difficulty: 'Standard'
        }
      ],
      communications: {
        outreachEmail: {
          subject: 'NexusAI Technologies - Future Opportunities',
          body: `Hi Sarah,\n\nThank you for your interest in NexusAI. We love your frontend design craft. We will keep your resume on file for future mid-level frontend opportunities.`
        },
        rejectionEmail: {
          subject: 'Your Application for Senior Full-Stack AI Engineer @ NexusAI',
          body: `Hi Sarah,\n\nThank you for applying to NexusAI Technologies. At this time, we are prioritizing candidates with 5+ years of experience and deep production vector retrieval architecture for this Senior Tech Lead role. We were very impressed by your frontend craft and will keep your profile active for future frontend opportunities.\n\nWarm regards,\nNexusAI Talent Team`
        },
        recruiterNotes: 'Reject for Senior Lead role. Keep on file for mid-level Frontend/Design Technologist roles.'
      },
      rawResumeText: SAMPLE_RESUME_TEXTS.sarah_jenkins,
      evaluatedAt: '2026-08-28T02:30:00.000Z'
    },
    {
      id: 'cand-05',
      name: 'David Miller',
      email: 'david.miller.enterprise@corpmail.com',
      phone: '(214) 765-4321',
      currentRole: 'Senior Enterprise Java Developer',
      currentCompany: 'Titan Financial Solutions',
      totalExperienceYears: 10.0,
      matchScore: 37.0,
      tier: 'TIER_4_DO_NOT_PROCEED',
      recommendationVerdict: 'Reject',
      keyVerdictHeadline: '10 yrs legacy Java/Oracle enterprise exp; no commercial Python, modern TS, or GenAI',
      executiveSummary: 'David is an experienced enterprise Java/Spring Boot developer with 10 years in banking and Oracle PL/SQL. However, he possesses zero commercial experience with Python, TypeScript, modern React/Next.js, or Generative AI/RAG architectures, making him an unsuitable fit for this modern AI stack.',
      mustHaveChecks: [
        {
          requirement: '5+ years software engineering experience in Python and TypeScript',
          status: 'NOT_MET',
          evidence: '10 years in Java and SQL; no commercial Python or TypeScript experience.'
        },
        {
          requirement: 'Production RAG systems with vector databases (Pinecone, Qdrant)',
          status: 'NOT_MET',
          evidence: 'No experience with vector search, RAG, or AI models.'
        },
        {
          requirement: 'Expertise in modern frontend (React, Next.js 14+, Tailwind CSS)',
          status: 'NOT_MET',
          evidence: 'Zero modern React or Next.js experience.'
        },
        {
          requirement: 'Backend API development with FastAPI/Express and async processing',
          status: 'NOT_MET',
          evidence: 'Enterprise Spring Boot / Java EE REST/SOAP; no Python FastAPI or async Node.js.'
        },
        {
          requirement: 'Technical leadership or mentoring experience on complex projects',
          status: 'MET',
          evidence: 'Led transaction gateway architecture in financial enterprise.'
        }
      ],
      dimensions: {
        technicalSkills: {
          category: 'technicalSkills',
          score: 15.0,
          weight: 0.35,
          weightedScore: 5.25,
          rationale: 'Skills are entirely centered on legacy Java/Oracle; complete mismatch with Python/TypeScript AI stack.',
          evidenceFound: ['Java 8/11/17', 'Spring Boot', 'Oracle Database', 'PCI-DSS'],
          missingOrWeak: ['No Python', 'No TypeScript', 'No React/Next.js', 'No GenAI / RAG']
        },
        experienceSeniority: {
          category: 'experienceSeniority',
          score: 70.0,
          weight: 0.25,
          weightedScore: 17.5,
          rationale: '10 years of solid software tenure in enterprise environments.',
          evidenceFound: ['10 years continuous software engineering'],
          missingOrWeak: []
        },
        domainIndustryFit: {
          category: 'domainIndustryFit',
          score: 20.0,
          weight: 0.20,
          weightedScore: 4.0,
          rationale: 'Legacy banking enterprise background with no overlap with modern AI startup/platform workflows.',
          evidenceFound: ['Enterprise financial systems'],
          missingOrWeak: ['No GenAI domain experience']
        },
        softSkillsLeadership: {
          category: 'softSkillsLeadership',
          score: 50.0,
          weight: 0.12,
          weightedScore: 6.0,
          rationale: 'Experienced enterprise dev, standard compliance adherence.',
          evidenceFound: [],
          missingOrWeak: []
        },
        educationCertifications: {
          category: 'educationCertifications',
          score: 60.0,
          weight: 0.08,
          weightedScore: 4.8,
          rationale: 'B.S. in Information Technology from UT Dallas.',
          evidenceFound: ['UT Dallas B.S. IT (2014)'],
          missingOrWeak: []
        }
      },
      keyStrengths: [
        'Extensive enterprise transaction safety and regulatory compliance (PCI-DSS)',
        'Deep relational database tuning (Oracle PL/SQL)'
      ],
      criticalGaps: [
        'Complete absence of required modern stack: No Python, TypeScript, React, Next.js, or GenAI/RAG skills'
      ],
      riskFactors: [
        'Severe mismatch with technology requirements; would require multi-month retraining'
      ],
      interviewKit: [],
      communications: {
        outreachEmail: {
          subject: 'NexusAI Technologies Application',
          body: `Hi David,\n\nThank you for reaching out to NexusAI. We will keep your resume on file.`
        },
        rejectionEmail: {
          subject: 'Your Application with NexusAI Technologies',
          body: `Hi David,\n\nThank you for your interest in NexusAI Technologies. At this time, our Senior Full-Stack AI role strictly requires commercial production experience in Python, Next.js 14, and vector database RAG architectures. As your background is centered in Java enterprise development, we will not be moving forward with your candidacy for this role.\n\nWe wish you the best in your career pursuits.\n\nSincerely,\nNexusAI Talent Team`
        },
        recruiterNotes: 'Clear reject due to total technology mismatch.'
      },
      rawResumeText: SAMPLE_RESUME_TEXTS.david_miller,
      evaluatedAt: '2026-08-28T02:30:00.000Z'
    }
  ],
  executiveBriefing: {
    topCandidateHighlights: 'Elena Rostova (#1, 95.9%) and Amina Al-Mansoor (#2, 90.8%) represent the clear Tier 1 shortlist. Elena is a battle-tested Staff Tech Lead with high-volume RAG and Next.js 14 expertise. Amina brings exceptional clinical trial RAG systems and rigorous data privacy mastery.',
    marketFitAssessment: 'The candidate pool demonstrates a clear bifurcation between modern Full-Stack AI engineers (Elena, Amina), infrastructure specialists (Marcus), early-career frontend specialists (Sarah), and legacy enterprise engineers (David).',
    hiringRisksAndTradeoffs: 'Hiring Marcus Chen would provide top-tier backend infrastructure resilience but create a critical bottleneck on frontend execution. Sarah Jenkins offers strong UI craft but lacks senior system architecture and vector DB depth.',
    recommendedNextSteps: [
      'Immediately advance Elena Rostova to final Hiring Manager & Architecture panel.',
      'Schedule Amina Al-Mansoor for Technical Deep Dive focused on Next.js 14 and large-scale ingestion.',
      'Route Marcus Chen to the Principal Cloud Infrastructure pipeline.',
      'Send tailored constructive rejection letters to Sarah Jenkins and David Miller.'
    ]
  },
  statistics: {
    totalCandidates: 5,
    averageScore: 69.1,
    topScore: 95.9,
    tierCounts: {
      tier1: 2,
      tier2: 0,
      tier3: 1,
      tier4: 2
    }
  }
};
