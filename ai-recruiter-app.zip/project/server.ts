import express from 'express';
import path from 'path';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { PDFParse } from 'pdf-parse';
import mammoth from 'mammoth';

dotenv.config();

const app = express();
const PORT = 3000;

// NOTE: resumes are sent to /api/parse-resume as base64, which inflates the
// original file size by ~33%. 20mb gives headroom for multi-page PDFs/DOCX
// files (each individually capped at 8MB below) while still bounding memory use.
app.use(express.json({ limit: '20mb' }));

// Body-parser (express.json) throws *before* reaching any route handler when
// the request body is malformed. Left uncaught, Express falls back to its
// default HTML error page, which breaks every frontend `await res.json()`
// call with a confusing "Unexpected token '<'" error instead of a clean
// message. Catch that specific failure mode here and always respond JSON.
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Malformed JSON in request body.' });
  }
  if (err && err.type === 'entity.too.large') {
    return res.status(413).json({ error: 'Request payload too large.' });
  }
  next(err);
});

const MAX_RESUME_FILE_BYTES = 8 * 1024 * 1024; // 8MB per resume file

const DEFAULT_SCORING_WEIGHTS = {
  technicalSkills: 0.35,
  experienceSeniority: 0.25,
  domainIndustryFit: 0.20,
  softSkillsLeadership: 0.12,
  educationCertifications: 0.08,
};

// Guarantees a JobProfile always has a complete, numeric set of weights,
// even if the client sent a hand-edited or partially-generated profile.
// Without this, a single missing weight silently propagates as
// `undefined * number = NaN` through every downstream score calculation.
function coerceScoringWeights(weights: any): typeof DEFAULT_SCORING_WEIGHTS {
  const safe = { ...DEFAULT_SCORING_WEIGHTS };
  if (weights && typeof weights === 'object') {
    for (const key of Object.keys(safe) as (keyof typeof safe)[]) {
      const val = Number(weights[key]);
      if (Number.isFinite(val) && val >= 0) {
        safe[key] = val;
      }
    }
  }
  return safe;
}

// Gemini's structured-output mode is reliable but not infallible: truncated
// responses (token limits), transient formatting slips, or safety-filtered
// partial output can all produce a response.text that isn't valid JSON.
// Centralizing the parse gives every route the same clear, actionable error
// instead of a raw "Unexpected token" message leaking to the client.
function safeJsonParse(text: string | undefined, context: string): any {
  if (!text) {
    throw new Error(`AI service returned an empty response while ${context}. Please retry.`);
  }
  try {
    return JSON.parse(text);
  } catch (err) {
    console.error(`JSON parse failure while ${context}:`, err, '\nRaw response (truncated):', text.slice(0, 500));
    throw new Error(`AI service returned malformed data while ${context}. Please retry.`);
  }
}

function asStringArray(value: any): string[] {
  return Array.isArray(value) ? value.filter((v) => typeof v === 'string') : [];
}

// Lazy initializer for Gemini client
let genAIClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!genAIClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    genAIClient = new GoogleGenAI({
      apiKey: apiKey || '',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return genAIClient;
}

// Fails fast with a clear, actionable message instead of letting every route
// make a doomed API call with an empty key and surface a confusing
// authentication error from Google's API deep in a stack trace.
function requireApiKeyOr503(res: express.Response): boolean {
  if (!process.env.GEMINI_API_KEY) {
    res.status(503).json({
      error: 'GEMINI_API_KEY is not configured on the server. Set it in your environment/secrets and restart the server.',
    });
    return false;
  }
  return true;
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// API: Parse an uploaded resume file (PDF / DOCX / plain text) into raw text.
// Plain text formats (.txt/.md/.json) are handled client-side and never hit
// this route; this exists specifically because binary formats cannot be
// read with FileReader.readAsText() without producing garbage/mojibake.
app.post('/api/parse-resume', async (req, res) => {
  try {
    const { fileName, fileBase64 } = req.body;

    if (!fileName || typeof fileName !== 'string') {
      return res.status(400).json({ error: 'fileName is required.' });
    }
    if (!fileBase64 || typeof fileBase64 !== 'string') {
      return res.status(400).json({ error: 'fileBase64 is required.' });
    }

    const ext = fileName.toLowerCase().split('.').pop() || '';
    if (!['pdf', 'docx'].includes(ext)) {
      return res.status(400).json({
        error: `Unsupported file type ".${ext}". Only .pdf and .docx files are parsed server-side (.txt/.md/.json are read directly in-browser).`,
      });
    }

    let buffer: Buffer;
    try {
      buffer = Buffer.from(fileBase64, 'base64');
    } catch {
      return res.status(400).json({ error: 'fileBase64 could not be decoded. The file may be corrupted.' });
    }

    if (buffer.length === 0) {
      return res.status(400).json({ error: 'Uploaded file is empty.' });
    }
    if (buffer.length > MAX_RESUME_FILE_BYTES) {
      return res.status(413).json({
        error: `File exceeds the ${(MAX_RESUME_FILE_BYTES / (1024 * 1024)).toFixed(0)}MB limit for resume uploads.`,
      });
    }

    let text = '';
    if (ext === 'pdf') {
      try {
        const parser = new PDFParse({ data: buffer });
        const result = await parser.getText();
        await parser.destroy();
        // pdf-parse inserts "-- N of M --" page-boundary markers into the
        // concatenated text; strip them so they don't pollute the resume
        // text that gets sent into the LLM evaluation prompt.
        text = (result.text || '').replace(/--\s*\d+\s*of\s*\d+\s*--/g, '').trim();
      } catch (err: any) {
        console.error('PDF parse error:', err);
        return res.status(422).json({
          error: `Could not read "${fileName}". It may be corrupted, password-protected, or an encrypted PDF.`,
        });
      }
    } else {
      try {
        const result = await mammoth.extractRawText({ buffer });
        text = (result.value || '').trim();
      } catch (err: any) {
        console.error('DOCX parse error:', err);
        return res.status(422).json({
          error: `Could not read "${fileName}". The .docx file may be corrupted or in an unsupported format.`,
        });
      }
    }

    if (!text) {
      return res.status(422).json({
        error: `No extractable text found in "${fileName}". It may be a scanned/image-only document — try a text-based export instead.`,
      });
    }

    res.json({ text, fileName, charCount: text.length });
  } catch (error: any) {
    console.error('Error parsing resume file:', error);
    res.status(500).json({ error: error.message || 'Failed to parse resume file.' });
  }
});

// API: Analyze Job Description and formulate 5-pillar rubric
app.post('/api/analyze-job', async (req, res) => {
  try {
    const { jobText } = req.body;
    if (!jobText || typeof jobText !== 'string' || !jobText.trim()) {
      return res.status(400).json({ error: 'jobText is required and must be a non-empty string.' });
    }
    if (!requireApiKeyOr503(res)) return;

    const ai = getGeminiClient();
    const prompt = `You are an elite Talent Acquisition Leader and Executive Tech Recruiter.
Analyze the following Job Description and extract structured requirements, core responsibilities, seniority bar, and formulate an optimal 5-pillar scoring rubric with weights that sum to 1.0 (100%).

Job Description:
"""
${jobText}
"""

Return a JSON object conforming strictly to the requested schema.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: 'Job Title' },
            company: { type: Type.STRING, description: 'Hiring Company name or "Confidential Client"' },
            department: { type: Type.STRING, description: 'Department or Team name' },
            location: { type: Type.STRING, description: 'Location and Work Arrangement (e.g. Remote, Hybrid, San Francisco)' },
            employmentType: { type: Type.STRING, description: 'Full-time, Contract, Part-time' },
            seniorityLevel: { type: Type.STRING, description: 'e.g. Senior / Staff, Mid-level, Lead, Principal' },
            experienceRequiredYears: { type: Type.NUMBER, description: 'Minimum required years of professional experience' },
            summary: { type: Type.STRING, description: 'Crisp 2-3 sentence executive overview of the role and mission' },
            mustHaveRequirements: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Strict non-negotiable prerequisites (4-6 items)'
            },
            niceToHaveRequirements: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Bonus skills and preferred qualifications (3-5 items)'
            },
            keyResponsibilities: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Core daily responsibilities and deliverables (4-6 items)'
            },
            coreTechStack: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Key technologies, tools, and platforms mentioned'
            },
            scoringWeights: {
              type: Type.OBJECT,
              properties: {
                technicalSkills: { type: Type.NUMBER, description: 'Weight between 0.0 and 1.0 (e.g. 0.35)' },
                experienceSeniority: { type: Type.NUMBER, description: 'Weight between 0.0 and 1.0 (e.g. 0.25)' },
                domainIndustryFit: { type: Type.NUMBER, description: 'Weight between 0.0 and 1.0 (e.g. 0.20)' },
                softSkillsLeadership: { type: Type.NUMBER, description: 'Weight between 0.0 and 1.0 (e.g. 0.12)' },
                educationCertifications: { type: Type.NUMBER, description: 'Weight between 0.0 and 1.0 (e.g. 0.08)' },
              },
              required: ['technicalSkills', 'experienceSeniority', 'domainIndustryFit', 'softSkillsLeadership', 'educationCertifications'],
            }
          },
          required: [
            'title', 'company', 'department', 'location', 'employmentType',
            'seniorityLevel', 'experienceRequiredYears', 'summary',
            'mustHaveRequirements', 'niceToHaveRequirements', 'keyResponsibilities',
            'coreTechStack', 'scoringWeights'
          ]
        }
      }
    });

    const parsed = safeJsonParse(response.text, 'analyzing the job description');
    const id = 'job-' + Date.now().toString(36);

    // Normalize weights to sum exactly to 1.0
    const rawWeights = coerceScoringWeights(parsed.scoringWeights);
    const totalWeight: number = (Object.values(rawWeights) as number[]).reduce((a, b) => a + b, 0) || 1;
    const normalizedWeights = {
      technicalSkills: Math.round((rawWeights.technicalSkills / totalWeight) * 100) / 100,
      experienceSeniority: Math.round((rawWeights.experienceSeniority / totalWeight) * 100) / 100,
      domainIndustryFit: Math.round((rawWeights.domainIndustryFit / totalWeight) * 100) / 100,
      softSkillsLeadership: Math.round((rawWeights.softSkillsLeadership / totalWeight) * 100) / 100,
      educationCertifications: Math.round((rawWeights.educationCertifications / totalWeight) * 100) / 100,
    };

    // Defensive normalization: the LLM occasionally omits an optional-feeling
    // array/string field despite the schema's `required` list. Filling in
    // safe defaults here (rather than trusting `...parsed`) prevents
    // undefined values from reaching the React components, most of which
    // call `.map()` directly on these fields and would otherwise crash the
    // whole tab with a white screen.
    res.json({
      id,
      title: parsed.title || 'Untitled Role',
      company: parsed.company || 'Confidential Client',
      department: parsed.department || '',
      location: parsed.location || '',
      employmentType: parsed.employmentType || 'Full-time',
      seniorityLevel: parsed.seniorityLevel || '',
      experienceRequiredYears: Number.isFinite(Number(parsed.experienceRequiredYears)) ? Number(parsed.experienceRequiredYears) : 0,
      summary: parsed.summary || '',
      mustHaveRequirements: asStringArray(parsed.mustHaveRequirements),
      niceToHaveRequirements: asStringArray(parsed.niceToHaveRequirements),
      keyResponsibilities: asStringArray(parsed.keyResponsibilities),
      coreTechStack: asStringArray(parsed.coreTechStack),
      scoringWeights: normalizedWeights,
    });
  } catch (error: any) {
    console.error('Error analyzing job:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze job description' });
  }
});

// API: Evaluate a Candidate Resume against Job Profile
app.post('/api/evaluate-candidate', async (req, res) => {
  try {
    const { jobProfile, resumeText, candidateId } = req.body;
    if (!jobProfile || !resumeText || typeof resumeText !== 'string' || !resumeText.trim()) {
      return res.status(400).json({ error: 'jobProfile and non-empty resumeText are required.' });
    }
    if (!requireApiKeyOr503(res)) return;

    // Guard against a hand-edited or partially-generated jobProfile missing
    // one or more weights — every downstream weightedScore/matchScore
    // computation depends on these being real numbers.
    jobProfile.scoringWeights = coerceScoringWeights(jobProfile.scoringWeights);

    const ai = getGeminiClient();
    const prompt = `You are a Principal AI Recruiter and Bar Raiser Evaluator.
Evaluate the following Candidate Resume rigorously and objectively against the target Job Profile and its 5-pillar scoring weights.

TARGET JOB PROFILE:
Title: ${jobProfile.title}
Seniority: ${jobProfile.seniorityLevel} (Req: ${jobProfile.experienceRequiredYears}+ years)
Must-Haves: ${JSON.stringify(jobProfile.mustHaveRequirements)}
Nice-To-Haves: ${JSON.stringify(jobProfile.niceToHaveRequirements)}
Tech Stack: ${JSON.stringify(jobProfile.coreTechStack)}
Weights: Technical(${jobProfile.scoringWeights.technicalSkills}), Experience(${jobProfile.scoringWeights.experienceSeniority}), Domain(${jobProfile.scoringWeights.domainIndustryFit}), Leadership(${jobProfile.scoringWeights.softSkillsLeadership}), Education(${jobProfile.scoringWeights.educationCertifications})

CANDIDATE RESUME TEXT:
"""
${resumeText}
"""

EVALUATION RULES:
1. Verify hard requirements objectively. Check if there is verifiable proof in the resume. Status must be MET, PARTIAL, or NOT_MET.
2. Score each of the 5 dimensions on a 0-100 scale based on demonstrable evidence (not mere keyword matching).
3. Compute the overall matchScore as the weighted average:
   matchScore = (technicalScore * techWeight) + (expScore * expWeight) + (domainScore * domainWeight) + (leadershipScore * leadWeight) + (educationScore * eduWeight).
4. Assign Tier strictly based on matchScore:
   - 88.0 - 100.0 => "TIER_1_TOP_SHORTLIST" (Recommendation: "Strong Hire")
   - 75.0 - 87.9 => "TIER_2_STRONG_CONTENDER" (Recommendation: "Hire" or "Leaning Hire")
   - 60.0 - 74.9 => "TIER_3_HOLD_RESERVE" (Recommendation: "Leaning Hire" or "Hold / Re-evaluate")
   - Below 60.0 => "TIER_4_DO_NOT_PROCEED" (Recommendation: "Reject")
5. Craft 2-4 candidate-specific Interview Probes with:
   - Targeted probing question addressing real gaps or verifying advanced claims
   - Recruiter intent
   - Positive signals to listen for
   - Red flag signals to watch out for
   - Difficulty level ("Standard", "Challenging", "Deep Dive")
6. Draft personalized communications:
   - Compelling executive Outreach Email tailored to candidate's background
   - Constructive, professional Rejection Email outlining specific skills prioritized
   - Recruiter internal notes

Return valid JSON conforming strictly to the response schema.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING, description: 'Candidate Full Name' },
            email: { type: Type.STRING, description: 'Candidate Email' },
            phone: { type: Type.STRING, description: 'Candidate Phone Number if present' },
            currentRole: { type: Type.STRING, description: 'Current or most recent Job Title' },
            currentCompany: { type: Type.STRING, description: 'Current or most recent Company' },
            totalExperienceYears: { type: Type.NUMBER, description: 'Estimated total years of professional experience' },
            matchScore: { type: Type.NUMBER, description: 'Overall composite match score from 0.0 to 100.0' },
            tier: {
              type: Type.STRING,
              enum: ['TIER_1_TOP_SHORTLIST', 'TIER_2_STRONG_CONTENDER', 'TIER_3_HOLD_RESERVE', 'TIER_4_DO_NOT_PROCEED'],
              description: 'Ranking tier'
            },
            recommendationVerdict: {
              type: Type.STRING,
              enum: ['Strong Hire', 'Hire', 'Leaning Hire', 'Hold / Re-evaluate', 'Reject'],
              description: 'Final hiring verdict'
            },
            keyVerdictHeadline: { type: Type.STRING, description: 'One-line punchy verdict summarizing key fit or blockers' },
            executiveSummary: { type: Type.STRING, description: 'Detailed 2-4 sentence executive overview of the candidate' },
            mustHaveChecks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  requirement: { type: Type.STRING },
                  status: { type: Type.STRING, enum: ['MET', 'PARTIAL', 'NOT_MET'] },
                  evidence: { type: Type.STRING, description: 'Quote or evidence from resume' }
                },
                required: ['requirement', 'status', 'evidence']
              }
            },
            dimensions: {
              type: Type.OBJECT,
              properties: {
                technicalSkills: {
                  type: Type.OBJECT,
                  properties: {
                    score: { type: Type.NUMBER },
                    rationale: { type: Type.STRING },
                    evidenceFound: { type: Type.ARRAY, items: { type: Type.STRING } },
                    missingOrWeak: { type: Type.ARRAY, items: { type: Type.STRING } }
                  },
                  required: ['score', 'rationale', 'evidenceFound', 'missingOrWeak']
                },
                experienceSeniority: {
                  type: Type.OBJECT,
                  properties: {
                    score: { type: Type.NUMBER },
                    rationale: { type: Type.STRING },
                    evidenceFound: { type: Type.ARRAY, items: { type: Type.STRING } },
                    missingOrWeak: { type: Type.ARRAY, items: { type: Type.STRING } }
                  },
                  required: ['score', 'rationale', 'evidenceFound', 'missingOrWeak']
                },
                domainIndustryFit: {
                  type: Type.OBJECT,
                  properties: {
                    score: { type: Type.NUMBER },
                    rationale: { type: Type.STRING },
                    evidenceFound: { type: Type.ARRAY, items: { type: Type.STRING } },
                    missingOrWeak: { type: Type.ARRAY, items: { type: Type.STRING } }
                  },
                  required: ['score', 'rationale', 'evidenceFound', 'missingOrWeak']
                },
                softSkillsLeadership: {
                  type: Type.OBJECT,
                  properties: {
                    score: { type: Type.NUMBER },
                    rationale: { type: Type.STRING },
                    evidenceFound: { type: Type.ARRAY, items: { type: Type.STRING } },
                    missingOrWeak: { type: Type.ARRAY, items: { type: Type.STRING } }
                  },
                  required: ['score', 'rationale', 'evidenceFound', 'missingOrWeak']
                },
                educationCertifications: {
                  type: Type.OBJECT,
                  properties: {
                    score: { type: Type.NUMBER },
                    rationale: { type: Type.STRING },
                    evidenceFound: { type: Type.ARRAY, items: { type: Type.STRING } },
                    missingOrWeak: { type: Type.ARRAY, items: { type: Type.STRING } }
                  },
                  required: ['score', 'rationale', 'evidenceFound', 'missingOrWeak']
                }
              },
              required: ['technicalSkills', 'experienceSeniority', 'domainIndustryFit', 'softSkillsLeadership', 'educationCertifications']
            },
            keyStrengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            criticalGaps: { type: Type.ARRAY, items: { type: Type.STRING } },
            riskFactors: { type: Type.ARRAY, items: { type: Type.STRING } },
            interviewKit: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  category: { type: Type.STRING },
                  question: { type: Type.STRING },
                  intent: { type: Type.STRING },
                  positiveSignals: { type: Type.ARRAY, items: { type: Type.STRING } },
                  redFlagSignals: { type: Type.ARRAY, items: { type: Type.STRING } },
                  difficulty: { type: Type.STRING, enum: ['Standard', 'Challenging', 'Deep Dive'] }
                },
                required: ['category', 'question', 'intent', 'positiveSignals', 'redFlagSignals', 'difficulty']
              }
            },
            communications: {
              type: Type.OBJECT,
              properties: {
                outreachEmail: {
                  type: Type.OBJECT,
                  properties: {
                    subject: { type: Type.STRING },
                    body: { type: Type.STRING }
                  },
                  required: ['subject', 'body']
                },
                rejectionEmail: {
                  type: Type.OBJECT,
                  properties: {
                    subject: { type: Type.STRING },
                    body: { type: Type.STRING }
                  },
                  required: ['subject', 'body']
                },
                recruiterNotes: { type: Type.STRING }
              },
              required: ['outreachEmail', 'rejectionEmail', 'recruiterNotes']
            }
          },
          required: [
            'name', 'email', 'currentRole', 'totalExperienceYears', 'matchScore',
            'tier', 'recommendationVerdict', 'keyVerdictHeadline', 'executiveSummary',
            'mustHaveChecks', 'dimensions', 'keyStrengths', 'criticalGaps',
            'riskFactors', 'interviewKit', 'communications'
          ]
        }
      }
    });

    const parsed = safeJsonParse(response.text, 'evaluating the candidate resume');
    const evalId = candidateId || 'cand-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);

    // Populate weighted scores
    const weights = jobProfile.scoringWeights;
    const dimensions = {
      technicalSkills: {
        category: 'technicalSkills',
        score: parsed.dimensions?.technicalSkills?.score ?? 0,
        weight: weights.technicalSkills,
        weightedScore: Number(((parsed.dimensions?.technicalSkills?.score ?? 0) * weights.technicalSkills).toFixed(2)),
        rationale: parsed.dimensions?.technicalSkills?.rationale ?? '',
        evidenceFound: parsed.dimensions?.technicalSkills?.evidenceFound ?? [],
        missingOrWeak: parsed.dimensions?.technicalSkills?.missingOrWeak ?? []
      },
      experienceSeniority: {
        category: 'experienceSeniority',
        score: parsed.dimensions?.experienceSeniority?.score ?? 0,
        weight: weights.experienceSeniority,
        weightedScore: Number(((parsed.dimensions?.experienceSeniority?.score ?? 0) * weights.experienceSeniority).toFixed(2)),
        rationale: parsed.dimensions?.experienceSeniority?.rationale ?? '',
        evidenceFound: parsed.dimensions?.experienceSeniority?.evidenceFound ?? [],
        missingOrWeak: parsed.dimensions?.experienceSeniority?.missingOrWeak ?? []
      },
      domainIndustryFit: {
        category: 'domainIndustryFit',
        score: parsed.dimensions?.domainIndustryFit?.score ?? 0,
        weight: weights.domainIndustryFit,
        weightedScore: Number(((parsed.dimensions?.domainIndustryFit?.score ?? 0) * weights.domainIndustryFit).toFixed(2)),
        rationale: parsed.dimensions?.domainIndustryFit?.rationale ?? '',
        evidenceFound: parsed.dimensions?.domainIndustryFit?.evidenceFound ?? [],
        missingOrWeak: parsed.dimensions?.domainIndustryFit?.missingOrWeak ?? []
      },
      softSkillsLeadership: {
        category: 'softSkillsLeadership',
        score: parsed.dimensions?.softSkillsLeadership?.score ?? 0,
        weight: weights.softSkillsLeadership,
        weightedScore: Number(((parsed.dimensions?.softSkillsLeadership?.score ?? 0) * weights.softSkillsLeadership).toFixed(2)),
        rationale: parsed.dimensions?.softSkillsLeadership?.rationale ?? '',
        evidenceFound: parsed.dimensions?.softSkillsLeadership?.evidenceFound ?? [],
        missingOrWeak: parsed.dimensions?.softSkillsLeadership?.missingOrWeak ?? []
      },
      educationCertifications: {
        category: 'educationCertifications',
        score: parsed.dimensions?.educationCertifications?.score ?? 0,
        weight: weights.educationCertifications,
        weightedScore: Number(((parsed.dimensions?.educationCertifications?.score ?? 0) * weights.educationCertifications).toFixed(2)),
        rationale: parsed.dimensions?.educationCertifications?.rationale ?? '',
        evidenceFound: parsed.dimensions?.educationCertifications?.evidenceFound ?? [],
        missingOrWeak: parsed.dimensions?.educationCertifications?.missingOrWeak ?? []
      }
    };

    // Calculate recalculation sum
    const totalWeightedScore = Number(
      (dimensions.technicalSkills.weightedScore +
       dimensions.experienceSeniority.weightedScore +
       dimensions.domainIndustryFit.weightedScore +
       dimensions.softSkillsLeadership.weightedScore +
       dimensions.educationCertifications.weightedScore).toFixed(1)
    );

    const interviewKit = (parsed.interviewKit || []).map((item: any, idx: number) => ({
      id: `probe-${idx + 1}-${Date.now().toString(36)}`,
      ...item
    }));

    const result = {
      id: evalId,
      ...parsed,
      matchScore: totalWeightedScore,
      dimensions,
      interviewKit,
      rawResumeText: resumeText,
      evaluatedAt: new Date().toISOString()
    };

    res.json(result);
  } catch (error: any) {
    console.error('Error evaluating candidate:', error);
    res.status(500).json({ error: error.message || 'Failed to evaluate candidate resume' });
  }
});

// API: Synthesize Executive Briefing and Cross-Candidate Comparison
app.post('/api/synthesize-ranking', async (req, res) => {
  try {
    const { jobProfile, candidates } = req.body;
    if (!jobProfile || !Array.isArray(candidates) || candidates.length === 0) {
      return res.status(400).json({ error: 'jobProfile and candidates array are required.' });
    }
    if (!requireApiKeyOr503(res)) return;

    const ai = getGeminiClient();
    const candidateSummaries = candidates.map((c: any, idx: number) => ({
      rank: idx + 1,
      name: c.name,
      title: c.currentRole,
      matchScore: c.matchScore,
      tier: c.tier,
      verdict: c.recommendationVerdict,
      headline: c.keyVerdictHeadline,
      strengths: c.keyStrengths?.slice(0, 2),
      gaps: c.criticalGaps?.slice(0, 2)
    }));

    const prompt = `You are an Executive Talent Partner delivering a strategic Candidate Ranking Briefing to the VP of Engineering and Hiring Committee.

Role: ${jobProfile.title} at ${jobProfile.company}
Candidate Leaderboard (Sorted by Match Score):
${JSON.stringify(candidateSummaries, null, 2)}

Provide a concise, high-level Strategic Executive Briefing:
1. topCandidateHighlights: Who are the standout candidates and why?
2. marketFitAssessment: What patterns or bifurcations exist in this applicant pool?
3. hiringRisksAndTradeoffs: What are key tradeoffs between the top candidates (e.g. backend scale vs frontend depth vs domain experience)?
4. recommendedNextSteps: 3-5 concrete action items for the hiring team.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topCandidateHighlights: { type: Type.STRING },
            marketFitAssessment: { type: Type.STRING },
            hiringRisksAndTradeoffs: { type: Type.STRING },
            recommendedNextSteps: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ['topCandidateHighlights', 'marketFitAssessment', 'hiringRisksAndTradeoffs', 'recommendedNextSteps']
        }
      }
    });

    const briefing = safeJsonParse(response.text, 'synthesizing the executive briefing');
    res.json({
      topCandidateHighlights: briefing.topCandidateHighlights || '',
      marketFitAssessment: briefing.marketFitAssessment || '',
      hiringRisksAndTradeoffs: briefing.hiringRisksAndTradeoffs || '',
      recommendedNextSteps: asStringArray(briefing.recommendedNextSteps),
    });
  } catch (error: any) {
    console.error('Error synthesizing ranking:', error);
    res.status(500).json({ error: error.message || 'Failed to synthesize ranking' });
  }
});

// API: Batch Evaluate multiple resumes in parallel
app.post('/api/batch-evaluate', async (req, res) => {
  try {
    const { jobProfile, resumes } = req.body;
    if (!jobProfile || !Array.isArray(resumes) || resumes.length === 0) {
      return res.status(400).json({ error: 'jobProfile and resumes array are required.' });
    }
    if (!requireApiKeyOr503(res)) return;

    // Process up to 5 in parallel
    const ai = getGeminiClient();
    const evaluationPromises = resumes.map(async (resume: { id: string; name?: string; content: string }) => {
      try {
        const prompt = `Evaluate candidate against ${jobProfile.title}.
Must-Haves: ${JSON.stringify(jobProfile.mustHaveRequirements)}
Resume:
${resume.content}`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.7-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                email: { type: Type.STRING },
                currentRole: { type: Type.STRING },
                totalExperienceYears: { type: Type.NUMBER },
                matchScore: { type: Type.NUMBER },
                tier: {
                  type: Type.STRING,
                  enum: ['TIER_1_TOP_SHORTLIST', 'TIER_2_STRONG_CONTENDER', 'TIER_3_HOLD_RESERVE', 'TIER_4_DO_NOT_PROCEED']
                },
                recommendationVerdict: {
                  type: Type.STRING,
                  enum: ['Strong Hire', 'Hire', 'Leaning Hire', 'Hold / Re-evaluate', 'Reject']
                },
                keyVerdictHeadline: { type: Type.STRING },
                executiveSummary: { type: Type.STRING },
                keyStrengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                criticalGaps: { type: Type.ARRAY, items: { type: Type.STRING } },
                riskFactors: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ['name', 'email', 'currentRole', 'totalExperienceYears', 'matchScore', 'tier', 'recommendationVerdict', 'keyVerdictHeadline', 'executiveSummary', 'keyStrengths', 'criticalGaps', 'riskFactors']
            }
          }
        });

        const parsed = safeJsonParse(response.text, `evaluating ${resume.name || resume.id}`);
        return {
          id: resume.id,
          ...parsed,
          rawResumeText: resume.content,
          evaluatedAt: new Date().toISOString()
        };
      } catch (err: any) {
        console.error(`Batch evaluation failed for resume ${resume.id}:`, err);
        return {
          id: resume.id,
          error: err.message || 'Evaluation failed'
        };
      }
    });

    const results = await Promise.all(evaluationPromises);
    res.json({ results });
  } catch (error: any) {
    console.error('Error in batch evaluate:', error);
    res.status(500).json({ error: error.message || 'Batch evaluation failed' });
  }
});

// 404 for unknown API routes — without this, an unmatched /api/* request
// falls through to the SPA/static handler below and returns index.html with
// a 200 status, which the frontend then fails to parse as JSON.
app.use('/api', (req, res) => {
  res.status(404).json({ error: `No API route: ${req.method} ${req.path}` });
});

// Final safety net: any error thrown or passed to next() by a route handler
// that wasn't already caught (e.g. a bug in future code) still gets a JSON
// response instead of Express's default HTML error page.
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Unhandled error:', err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Internal server error.' });
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Recruiter server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
